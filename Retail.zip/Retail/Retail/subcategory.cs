﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;

namespace Retail
{
    public partial class subcategory : Form
    {
       

         int indexRow;
       
        public subcategory()
        {
                InitializeComponent();
           
        }



        private void subcategory_Load(object sender, EventArgs e)
        {
         
            bind();
            loadsubcategory();
            cbcategory.SelectedIndex = 0;
           
        }

        private void GvSubcatergory_Dobleclick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = GvSubcategory.Rows[indexRow];
            cbcategory.Text = row.Cells[2].Value.ToString();
            txtscname.Text = row.Cells[3].Value.ToString();
            btnscsave.Text = "Update";
        }

        private void Gv_Mouseup(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.GvSubcategory.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.GvSubcategory.CurrentCell = this.GvSubcategory.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.GvSubcategory, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void contextmenustrip(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = GvSubcategory.Rows[indexRow];
                    hstbl.Add("@status", "Delete");
                    hstbl.Add("updatedby", Global.UserID);
                    hstbl.Add("@SubCategoryId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_subcategory_master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" Subcategory Details Deleted Successfully.", "Subcategory Alert");
                        cbcategory.Text = String.Empty;
                        txtscname.Text = String.Empty;
                        loadsubcategory();
                    }
                }
            }
                 catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

 

        
        private void btnscsave_Click(object sender, EventArgs e)
        {

             try
            {
                if (txtscname.Text != String.Empty )
                {
                    if (btnscsave.Text == "Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");
               
                        hstbl.Add("@CategoryId", cbcategory.SelectedValue);
                        hstbl.Add("@CategoryName", txtscname.Text.Trim());
                        hstbl.Add("@createdby", 1);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_subcategory_master", hstbl);
                        if (intidentity > 0)
                        {
                            MessageBox.Show("Subcategory Details Saved Sucessfully", "Subcategory Alert");
                       
                            txtscname.Text = String.Empty;
                            loadsubcategory();
                            bind();
                        }
                       
                    }

                    else if (btnscsave.Text == "Update")
                    {
                        Hashtable hstbl = new Hashtable();
                        DataGridViewRow row = GvSubcategory.Rows[indexRow];
                        hstbl.Add("@status","update");
                        hstbl.Add("@CategoryId",cbcategory.SelectedValue);
                        hstbl.Add("@CategoryName", txtscname.Text.Trim());
                        hstbl.Add("updatedby", Global.UserID);
                        hstbl.Add("@SubCategoryId", row.Cells[1].Value);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_subcategory_master", hstbl);
                        if (intidentity > 0)
                        {
                            MessageBox.Show("Subcategory  Details Updated Sucessfully", "Subcategory  Alert");
                            
                            
                            loadsubcategory();
                            bind();
                            btnscsave.Text = "Save";
                        }
                        
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter the Subcategory");

                }

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }



    protected void loadsubcategory()
{
    try
    {
        Hashtable hstbl = new Hashtable();
        hstbl.Add("@status", "Get");
        DataSet ds = DataAccessLayer.GetDataset("sp_subcategory_master", hstbl);
        GvSubcategory.DataSource = ds.Tables[0];
        GvSubcategory.Columns[1].Visible = false;
        GvSubcategory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        DataGridViewCellStyle style = GvSubcategory.ColumnHeadersDefaultCellStyle;
        style.Alignment = DataGridViewContentAlignment.MiddleCenter;
        style.Font = new Font(GvSubcategory.Font, FontStyle.Bold);
        GvSubcategory.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkBlue;
        GvSubcategory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        GvSubcategory.EnableHeadersVisualStyles = false;
    }
    catch (Exception exceptionObj)
    {
        MessageBox.Show(exceptionObj.Message.ToString());
    }

}

        public void bind()
            
    {
        System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("catrgory_type_sp");

            if (dsLoad != null)
            {
                if (dsLoad.Rows.Count > 0)
                {
                    cbcategory.DataSource = new BindingSource(dsLoad, null);
                    cbcategory.DisplayMember = "CategoryName";
                    cbcategory.ValueMember = "CategoryId";
                   
                }
}
    }
    
}
}

