﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;

namespace Retail
{
    public partial class product : Form
    {
        int indexRow;
       
        public product()
        {
            InitializeComponent();
        }

        private void Gvproduct_doubleclick(object sender, DataGridViewCellEventArgs e)
        {


            indexRow = e.RowIndex;
            DataGridViewRow row = Gvproduct.Rows[indexRow];
            Global.New = "Edit";
           
        }

        private void GvProduct_MouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.Gvproduct.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.Gvproduct.CurrentCell = this.Gvproduct.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.Gvproduct, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void contextMenustripclick(object sender, EventArgs e)
        {
           
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtpname.Text != String.Empty && txtbarcode.Text != String.Empty && txtinternal.Text != String.Empty )
                {
                    if (btnsave.Text == "Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");
                        hstbl.Add("@ProductNo", txtproduct.Text.Trim());
                        hstbl.Add("@ProductName",txtpname.Text.Trim());
                        hstbl.Add("@BarcodeNo",txtbarcode.Text.Trim());
                         hstbl.Add("@InternalNo",txtinternal.Text.Trim());
                         hstbl.Add("@BrandId",cbbrand.SelectedValue);
                         hstbl.Add("@Unit",cbunit.SelectedValue);
                         hstbl.Add("@CategoryId",cbcategory.SelectedValue);
                         hstbl.Add("@SubCategoryId",cbsubcategory.SelectedValue);
                         hstbl.Add("@SubsSubCategoryId",cbssubcategory.SelectedValue);

                         hstbl.Add("@createdby", Global.UserID);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_product_Master", hstbl);
                        if (intidentity > 0)
                        {
                            MessageBox.Show("Product Details Saved Sucessfully", "Product Alert");

                            clear();
                            bind();
                            loadproduct();
                            bindgrid();
                            bind();
                        }

                    }

                    else if (btnsave.Text == "Update")
                    {
                        Hashtable hstbl = new Hashtable();
                        DataGridViewRow row = Gvproduct.Rows[indexRow];
                        hstbl.Add("@status", "update");
                        hstbl.Add("@ProductNo", txtproduct.Text.Trim());
                        hstbl.Add("@ProductName", txtpname.Text.Trim());
                        hstbl.Add("@BarcodeNo", txtbarcode.Text.Trim());
                        hstbl.Add("@InternalNo", txtinternal.Text.Trim());
                        hstbl.Add("@BrandId", cbbrand.SelectedValue);
                        hstbl.Add("@Unit", cbunit.SelectedValue);
                        hstbl.Add("@CategoryId", cbcategory.SelectedValue);
                        hstbl.Add("@SubCategoryId", cbsubcategory.SelectedValue);
                        hstbl.Add("@SubsSubCategoryId", cbssubcategory.SelectedValue);
                       
                        hstbl.Add("updatedby", Global.UserID);
                        hstbl.Add("@ProductId", row.Cells[1].Value);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_product_Master", hstbl);
                        if (intidentity > 0)
                        {
                            MessageBox.Show("Product  Details Updated Sucessfully", "Product  Alert");

                            clear();
                            bind();
                            loadproduct();
                            bindgrid();
                            btnsave.Text = "Save";
                        }

                    }
                }
                else
                {
                    MessageBox.Show("Please Enter the Product");

                }

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }

        protected void loadproduct()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@status", "get");
                DataSet ds = DataAccessLayer.GetDataset("sp_product_Master", hstbl);
                Gvproduct.DataSource = ds.Tables[0];
                Gvproduct.Columns[1].Visible = false;
                Gvproduct.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                Gvproduct.Columns[2].HeaderText = "P.No";
                Gvproduct.Columns[3].HeaderText = "P.Name";
                Gvproduct.Columns[4].HeaderText = "Barcode";
                Gvproduct.Columns[5].HeaderText = "Internal";
                Gvproduct.Columns[6].HeaderText = "Brand";
                Gvproduct.Columns[7].HeaderText = "Uom";
                Gvproduct.Columns[8].HeaderText = "Category";
                Gvproduct.Columns[9].HeaderText = "Subcategory";
                Gvproduct.Columns[10].HeaderText = "Item";
               
                DataGridViewCellStyle style = Gvproduct.ColumnHeadersDefaultCellStyle;
                style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                style.Font = new Font(Gvproduct.Font, FontStyle.Bold);
                Gvproduct.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkBlue;
                Gvproduct.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                Gvproduct.EnableHeadersVisualStyles = false;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }

        public void bind()
        {
            System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("catrgory_type_sp");

            
                if (dsLoad.Rows.Count > 0)
                {
                    cbcategory.DataSource = new BindingSource(dsLoad, null);
                    cbcategory.DisplayMember = "CategoryName";
                    cbcategory.ValueMember = "CategoryId";
                    cbcategory.SelectedIndex = 0;
                }
                System.Data.DataTable dsLoad1 = DataAccessLayer.GetDataTable("brand_type_sp");
                if (dsLoad1.Rows.Count > 0)
                {
                    cbbrand.DataSource = new BindingSource(dsLoad1, null);
                    cbbrand.DisplayMember = "BrandName";
                    cbbrand.ValueMember = "BrandId";
                    cbbrand.SelectedIndex = 0;
                    
                }

                System.Data.DataTable dsLoad2 = DataAccessLayer.GetDataTable("uom_type_sp");
                if (dsLoad2.Rows.Count > 0)
                {
                    cbunit.DataSource = new BindingSource(dsLoad2, null);
                    cbunit.DisplayMember = "UOM";
                    cbunit.ValueMember = "UOMId";
                    cbunit.SelectedIndex = 0;
                               }

                System.Data.DataTable dsLoad3 = DataAccessLayer.GetDataTable("subcategory_type");
                if (dsLoad3.Rows.Count > 0)
                {
                    cbsubcategory.DataSource = new BindingSource(dsLoad3, null);
                    cbsubcategory.DisplayMember = "CategoryName";
                    cbsubcategory.ValueMember = "SubCategoryId";
                    cbsubcategory.SelectedIndex = 0;
                }
                System.Data.DataTable dsLoad4 = DataAccessLayer.GetDataTable("sp_category_type_p");
                if (dsLoad4.Rows.Count > 0)
                {
                    cbssubcategory.DataSource = new BindingSource(dsLoad4, null);
                    cbssubcategory.DisplayMember = "CategoryName";
                    cbssubcategory.ValueMember = "SubsSubCategoryId";
                    cbssubcategory.SelectedIndex = 0;
                }
            
        }

        private void product_Load(object sender, EventArgs e)
        {
            bind();
            loadproduct();
            bindgrid();
        }
       
        public void clear()
        {
            
            txtproduct.Text = String.Empty;
            txtpname.Text = String.Empty;
            txtbarcode.Text = String.Empty;
            txtinternal.Text = String.Empty;
            cbbrand.Text = String.Empty;
            cbunit.Text = String.Empty;
            cbcategory.Text = String.Empty;
            cbsubcategory.Text = String.Empty;
            cbssubcategory.SelectedText = String.Empty;
           
        }

        public void bindgrid()
        {
            DataSet getquote = DataAccessLayer.GetDataSet("sp_product_fetch");
            if (getquote.Tables[0].Rows.Count > 0)
            {
                txtproduct.Text = getquote.Tables[0].Rows[0]["ProductNo"].ToString();
            }
            loadproduct();
        }

        private void editRowToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            DataGridViewRow row = Gvproduct.Rows[indexRow];
            txtproduct.Text = row.Cells[2].Value.ToString();
            txtpname.Text = row.Cells[3].Value.ToString();
              txtbarcode.Text = row.Cells[4].Value.ToString();
              txtinternal.Text = row.Cells[5].Value.ToString();
              cbbrand.Text = row.Cells[6].Value.ToString();
              cbunit.Text = row.Cells[7].Value.ToString();
              cbcategory.Text = row.Cells[8].Value.ToString();
              cbsubcategory.Text = row.Cells[9].Value.ToString();
              cbssubcategory.Text = row.Cells[10].Value.ToString();
              btnsave.Text = "Update";

            
        }

        private void deleteRowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = Gvproduct.Rows[indexRow];
                    hstbl.Add("@status", "Delete");
                    hstbl.Add("updatedby", Global.UserID);
                    hstbl.Add("@ProductId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_product_Master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" Product Details Deleted Successfully.", "product Alert");
                        clear();
                        loadproduct();
                        bindgrid();
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            } 
        }

        private void txtproduct_TextChanged(object sender, EventArgs e)
        {

        }

       
        
    }
}
