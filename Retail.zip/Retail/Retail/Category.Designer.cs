﻿namespace Retail
{
    partial class Category
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btncategory = new System.Windows.Forms.Button();
            this.lblcategory = new System.Windows.Forms.Label();
            this.txtcategory = new System.Windows.Forms.TextBox();
            this.GvCategory = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.GvCategory)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btncategory
            // 
            this.btncategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncategory.Location = new System.Drawing.Point(146, 86);
            this.btncategory.Name = "btncategory";
            this.btncategory.Size = new System.Drawing.Size(75, 23);
            this.btncategory.TabIndex = 0;
            this.btncategory.Text = "Save";
            this.btncategory.UseVisualStyleBackColor = true;
            this.btncategory.Click += new System.EventHandler(this.btncategory_Click);
            // 
            // lblcategory
            // 
            this.lblcategory.AutoSize = true;
            this.lblcategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcategory.Location = new System.Drawing.Point(56, 50);
            this.lblcategory.Name = "lblcategory";
            this.lblcategory.Size = new System.Drawing.Size(89, 13);
            this.lblcategory.TabIndex = 1;
            this.lblcategory.Text = "CategoryName";
            // 
            // txtcategory
            // 
            this.txtcategory.Location = new System.Drawing.Point(161, 47);
            this.txtcategory.Name = "txtcategory";
            this.txtcategory.Size = new System.Drawing.Size(150, 20);
            this.txtcategory.TabIndex = 2;
            // 
            // GvCategory
            // 
            this.GvCategory.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.GvCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvCategory.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.GvCategory.Location = new System.Drawing.Point(59, 115);
            this.GvCategory.Name = "GvCategory";
            this.GvCategory.ReadOnly = true;
            this.GvCategory.Size = new System.Drawing.Size(252, 150);
            this.GvCategory.TabIndex = 3;
            this.GvCategory.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GvCategory_CellDoubleClick);
            this.GvCategory.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.GvCategory_CellMouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(131, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.deleteRowToolStripMenuItem.Text = "DeleteRow";
            // 
            // Category
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 298);
            this.Controls.Add(this.GvCategory);
            this.Controls.Add(this.txtcategory);
            this.Controls.Add(this.lblcategory);
            this.Controls.Add(this.btncategory);
            this.Name = "Category";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Category";
            this.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            ((System.ComponentModel.ISupportInitialize)(this.GvCategory)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncategory;
        private System.Windows.Forms.Label lblcategory;
        private System.Windows.Forms.TextBox txtcategory;
        private System.Windows.Forms.DataGridView GvCategory;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
    }
}