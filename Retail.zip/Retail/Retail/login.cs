﻿using Sample;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Retail
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
            txtpassword.Text = string.Empty;
            // The password character is an asterisk.
            txtpassword.PasswordChar = '*';
            // The control will allow no more than 14 characters.
            txtpassword.MaxLength = 14;
        }

   
        private void login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.S)
            {
                LoginMethod();
            }
            if (e.Control && e.KeyCode == Keys.C)
            {
                this.Close();
            }
        }

        public void LoginMethod()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@UserName", txtusername.Text.Trim());
     

                var Encryptpwd = Retail.Models.Password.PwdCommon.Encrypt(txtpassword.Text.Trim());

                hstbl.Add("@Password", Encryptpwd);
                DataTable dt = DataAccessLayer.GetDataTable("sp_user_tbl", hstbl);

                if (dt != null && dt.Rows.Count > 0)
                {
                    Global.UserID = dt.Rows[0].ItemArray[0].ToString();
                    Global.UserName = dt.Rows[0].ItemArray[1].ToString();
                    MainMaster f = new MainMaster();

                    f.Show();
                    this.Visible = false;
                }
                else
                {
                    this.Visible = true;
                    MessageBox.Show("Invalid UserName/Password", "Retail - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void signin_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtusername.Text != String.Empty && txtpassword.Text != String.Empty)
                {
                    LoginMethod();
                }
                else
                {
                    MessageBox.Show("Please Enter Username and Password", "Login - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
 }
    }

