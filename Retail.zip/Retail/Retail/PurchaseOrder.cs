﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;
using System.Data.SqlClient;
using System.Configuration;




namespace Retail
{
    public partial class PurchaseOrder : Form
    {
        int indexRow;
        DataTable table, tbl_orders;

        public PurchaseOrder()
        {
            InitializeComponent();
        }
        private void PurchaseOrder_Load(object sender, EventArgs e)
        {
            tbl_orders = new DataTable();

            tbl_orders.TableName = "VariantTable";
            tbl_orders.Columns.Add("S.No", typeof(string));
            tbl_orders.Columns.Add("Product", typeof(string));
            tbl_orders.Columns.Add("Quantity", typeof(string));
            tbl_orders.Columns.Add("Unit", typeof(string));
            tbl_orders.Columns.Add("UOMId", typeof(string));
            tbl_orders.Columns.Add("Price", typeof(string));
            tbl_orders.Columns.Add("CategoryId", typeof(string));
            tbl_orders.Columns.Add("SubCategoryId", typeof(string));
            tbl_orders.Columns.Add("SubsSubCategoryId", typeof(string));
            tbl_orders.Columns.Add("BrandId", typeof(string));
            tbl_orders.PrimaryKey = new DataColumn[] { tbl_orders.Columns["S.No"] };
            tbl_orders.Columns[4].ColumnMapping = MappingType.Hidden;
            tbl_orders.Columns[6].ColumnMapping = MappingType.Hidden;
            tbl_orders.Columns[7].ColumnMapping = MappingType.Hidden;
            tbl_orders.Columns[8].ColumnMapping = MappingType.Hidden;
            tbl_orders.Columns[9].ColumnMapping = MappingType.Hidden;
            bind();
            showdata();
            loadproduct();
            tabledata();
            ChkVariant.Visible = false;
       
        }

        private void btnadd_Click(object sender, EventArgs e)
        {

            tbl_orders.Rows.Add(tbl_orders.Rows.Count + 1, txtproduct.Text.Trim(), txtquantity.Text.Trim(), cbunit.Text, cbunit.SelectedValue, txtprice.Text.Trim(), cbcategory.SelectedValue, cbscategory.SelectedValue, cbsubcategoryy.SelectedValue, cbbrand.SelectedValue);
            Gvpurchase.DataSource = tbl_orders;
            Gvpurchase.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            //if (table != null && table.Rows.Count > 0)
            //{
            //    DataRow[] rows = table.Select("productid" + indexrow);
            //    foreach (DataRow row in rows)
            //    {
            //        row["productid"] = Convert.ToInt32(tbl_orders.Rows.Count + 1).ToString();
            //        row["variant"] = "true";
            //    }
            //    table.AcceptChanges();

            //}
            //ChkVariant.Enabled = true;
           ChkVariant.Visible = true;

           //clear();
         
           
        }


        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtvproduct.Text != String.Empty && txtvquantity.Text != String.Empty)
                {
                    if (btnsave.Text == "save")
                    {

                        var MaxID = Gvpurchase.Rows.Cast<DataGridViewRow>().Max(r => Convert.ToInt32(r.Cells["S.No"].Value));
                        var chk = ChkVariant.Checked == true ? true : false;
                        table.Rows.Add(table.Rows.Count + 1, txtvproduct.Text.Trim(), txtvquantity.Text.Trim(), cbvunit.Text, cbvunit.SelectedValue, txtvprice.Text.Trim(), cbcategory.SelectedValue, cbscategory.SelectedValue, cbsubcategoryy.SelectedValue, cbbrand.SelectedValue, MaxID, chk);
                        GvPurchaseorder.DataSource = table;
                        GvPurchaseorder.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        txtvproduct.Text = string.Empty;
                        txtvquantity.Text = string.Empty;
                        cbvunit.Text = string.Empty;
                        cbvunit.SelectedIndex = -1;
                        txtvprice.Text = string.Empty;
                        GvPurchaseorder.DataSource = table;
                        GvPurchaseorder.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    }
                    else if (btnsave.Text == "Update")
                    {
                        if (table != null && indexRow>= 0)
                        {
                          
                            ////DataRow[] orderrow = tbl_orders.Select("Product" + txtproduct.Text);
                            DataRow[] rows = table.Select("P.No=" + indexRow);
                            if (rows.Length > 0)
                            {
                                foreach (DataRow row in rows)
                                {
                                    row["Product"] = txtvproduct.Text;
                                    row["Quantity"] = txtvquantity.Text.Trim();
                                    row["Unit"] = cbvunit.Text.Trim();
                                    row["UOMId"] = cbvunit.SelectedValue;
                                    row["Price"] = txtvprice.Text.Trim();

                                   // row["productid"] = orderrow[0]["S.No"].ToString();
                                    table.AcceptChanges();
                                    row.SetModified();
                                }

                                indexRow = 0;
                                GvPurchaseorder.DataSource = null;
                                GvPurchaseorder.DataSource = table;
                                GvPurchaseorder.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                            }
                            txtvproduct.Text = string.Empty;
                            txtvquantity.Text = string.Empty;
                            cbvunit.Text = string.Empty;
                            cbvunit.SelectedText = "select";
                            txtvprice.Text = string.Empty;
                            btnsave.Text = "save";
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter Product", "Add Product - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void ChkVariant_Click(object sender, EventArgs e)
        {
            try
            {
                if (ChkVariant.Checked == true)
                {
                        btnadd.Enabled = false;
                        GBproduct.Enabled = true;
                     
                        GBproduct.Visible = true;
                        GvPurchaseorder.Visible = true;
                        this.Size = new System.Drawing.Size(705, 584);
                        btnpurchase.Location = new System.Drawing.Point(343, 530);
                        btncancel.Location = new System.Drawing.Point(450, 530);

                        var MaxID = Gvpurchase.Rows.Cast<DataGridViewRow>().Max(r => Convert.ToString(r.Cells["Product"].Value));
                      
                        txtvproduct.Text = Convert.ToString(MaxID);

                 }
                else
                {
                    showdata();
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }
        private void btnpurchase_Click(object sender, EventArgs e)
        {
            
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@StatementType", "insert");
                hstbl.Add("@Purchaseno", txtpurchase.Text.Trim());
                hstbl.Add("@Purchasedate", ddtdate.Value);
                hstbl.Add("@warehouseId", cbware.SelectedValue);
                hstbl.Add("@VendorId", cbvendor.SelectedValue);
                //hstbl.Add("@CategoryId", cbcategory.SelectedValue);
                //hstbl.Add("@UOMId", cbunit.SelectedValue);
                //hstbl.Add("@BrandId", cbbrand.SelectedValue);
                //hstbl.Add("@Product", txtproduct.Text.Trim());
                //hstbl.Add("@SubCategoryId", cbscategory.SelectedValue);
                //hstbl.Add("@SubsSubCategoryId", cbsubcategoryy.SelectedValue);
                //hstbl.Add("@Quantity", txtquantity.Text.Trim());
                //if (txtprice.Text == "")
                //{
                //    hstbl.Add("@Price", 0.0);
                //}
                //else
                //{
                //    hstbl.Add("@Price", Convert.ToDecimal(txtprice.Text));
                //}
                string PurchaseXml = CreateproductXML();
                if (PurchaseXml.Length > 0)
                {
                    hstbl.Add("@PurchaseXml", PurchaseXml);
                }
            
               
                    string ProductXml = CreatedegreeXML();
                    if (ProductXml.Length > 0)
                    {
                        hstbl.Add("@ProductXml", ProductXml);
                    }
                    hstbl.Add("@createdby", Global.UserID);
                Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("Purchase_tbl_sp", hstbl);

                if (intidentity > 0)
                {
                    MessageBox.Show("Purchase Details Saved Sucessfully", "Purchase Alert");
                    bind();
                    loadproduct();
                    this.Gvpurchase.DataSource = null;
                    this.GvPurchaseorder.DataSource = null;
                    clear();
            }
        }



        private void GvPurchaseorder_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.GvPurchaseorder.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.GvPurchaseorder.CurrentCell = this.GvPurchaseorder.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.GvPurchaseorder, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void GvPurchaseorder_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (table != null)
                {
                    indexRow = e.RowIndex; // get the selected Row Index
                    DataRow row = table.Rows[indexRow];
                    indexRow = Convert.ToInt32(row[0].ToString());
                    txtvproduct.Text = row[1].ToString();
                    txtvquantity.Text = row[2].ToString();
                    cbvunit.Text = row[3].ToString();
                    txtvprice.Text = row[5].ToString();
                    btnsave.Text="Update";
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void deleteRowToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                if (MessageBox.Show("Do you want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    foreach (DataGridViewRow item in this.GvPurchaseorder.SelectedRows)
                    {
                        table.Rows.RemoveAt(indexRow);

                        btnsave.Text = "save";
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        public string CreateproductXML()
        {
            StringBuilder sb = new StringBuilder();

            foreach (DataRow dr in tbl_orders.Rows)
            {
                if (dr["Price"].ToString() == "")
                {
                    sb.Append(String.Format("<purchase  CategoryId='{0}'  SubCategoryId='{1}'  SubsSubCategoryId='{2}'  BrandId='{3}'  Product='{4}' Quantity='{5}' UOMId='{6}' Price='{7}'/>", dr["CategoryId"].ToString(), dr["SubCategoryId"].ToString(), dr["SubsSubCategoryId"].ToString(), dr["BrandId"].ToString(), dr["Product"].ToString(), dr["Quantity"].ToString(), dr["UOMId"].ToString(), Convert.ToDecimal(0)));
                }
                else
                {
                }
            }
            return String.Format("<ROOT>{0}</ROOT>", sb.ToString());
        }


        public string CreatedegreeXML()
        {
            StringBuilder sb = new StringBuilder();

            foreach (DataRow dr in table.Rows)
            {
                if (dr["Price"].ToString() == "")
                {
                    sb.Append(String.Format("<product  CategoryId='{0}'  SubCategoryId='{1}'  SubsSubCategoryId='{2}'  BrandId='{3}'  Product='{4}' Quantity='{5}' UOMId='{6}' Price='{7}'  Variantid='{8}'/>", dr["CategoryId"].ToString(), dr["SubCategoryId"].ToString(), dr["SubsSubCategoryId"].ToString(), dr["BrandId"].ToString(), dr["Product"].ToString(), dr["Quantity"].ToString(), dr["UOMId"].ToString(), 0,dr["Variantid"].ToString()));
                }
                else
                {
                    sb.Append(String.Format("<product  CategoryId='{0}'  SubCategoryId='{1}'  SubsSubCategoryId='{2}'  BrandId='{3}'  Product='{4}' Quantity='{5}' UOMId='{6}' Price='{7}' Variantid='{8}' /> ", dr["CategoryId"].ToString(), dr["SubCategoryId"].ToString(), dr["SubsSubCategoryId"].ToString(), dr["BrandId"].ToString(), dr["Product"].ToString(), dr["Quantity"].ToString(), dr["UOMId"].ToString(), Convert.ToDecimal(dr["Price"].ToString()),dr["Variantid"].ToString()));

                }
            }
            return String.Format("<ROOT>{0}</ROOT>", sb.ToString());
        }

        protected void loadproduct()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@StatementType", "select");
                //hstbl.Add("@Purchaseno", txtpurchase.Text.Trim());
                DataSet ds = DataAccessLayer.GetDataset("Purchase_tbl_sp", hstbl);
                txtpurchase.Text = ds.Tables[0].Rows[0]["Purchaseno"].ToString();

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }

        public void tabledata()
        {
            table = new DataTable();

            table.TableName = "VariantTable";

            table.Columns.Add("P.No", typeof(string));
            table.Columns.Add("Product", typeof(string));
            table.Columns.Add("Quantity", typeof(string));
            table.Columns.Add("Unit", typeof(string));
            table.Columns.Add("UOMId", typeof(string));
            table.Columns.Add("Price", typeof(string));
            table.Columns.Add("CategoryId", typeof(string));
            table.Columns.Add("SubCategoryId", typeof(string));
            table.Columns.Add("SubsSubCategoryId", typeof(string));
            table.Columns.Add("BrandId", typeof(string));
            table.Columns.Add("productid", typeof(string));
            table.Columns.Add("Variantid", typeof(string));
         //   table.PrimaryKey = new DataColumn[] { table.Columns["P.No"] };
            
            table.Columns[4].ColumnMapping = MappingType.Hidden;
            table.Columns[6].ColumnMapping = MappingType.Hidden;
            table.Columns[7].ColumnMapping = MappingType.Hidden;
            table.Columns[8].ColumnMapping = MappingType.Hidden;
            table.Columns[9].ColumnMapping = MappingType.Hidden;
            //table.Columns[10].ColumnMapping = MappingType.Hidden;
            //table.Columns[11].ColumnMapping = MappingType.Hidden;

           
        }
        public void showdata()
        {
            GBproduct.Visible=false;

            //GBproduct.Enabled = false;
            GvPurchaseorder.Visible = false;
           // GvPurchaseorder.Enabled = false;
            //GBproduct.Enabled = false;
            this.Size = new System.Drawing.Size(865, 354);
            btnpurchase.Location = new System.Drawing.Point(243, 430);
            btncancel.Location = new System.Drawing.Point(350, 430);
            ChkVariant.Visible = false;
            clear();
        }

        public void bind()
        {
            System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("catrgory_type_sp");


            if (dsLoad.Rows.Count > 0)
            {
                cbcategory.DataSource = new BindingSource(dsLoad, null);
                cbcategory.DisplayMember = "CategoryName";
                cbcategory.ValueMember = "CategoryId";
                cbcategory.SelectedIndex = -1;
                cbcategory.SelectedText = " please the select";

            }
            System.Data.DataTable dsLoad1 = DataAccessLayer.GetDataTable("warehouse_type_sp");
            if (dsLoad1.Rows.Count > 0)
            {
                cbware.DataSource = new BindingSource(dsLoad1, null);
                cbware.DisplayMember = "WarehouseName";
                cbware.ValueMember = "WarehouseId";
                cbware.SelectedIndex = -1;
                cbware.SelectedText = "select";

            }

            System.Data.DataTable dsLoad2 = DataAccessLayer.GetDataTable("uom_type_sp");
            if (dsLoad2.Rows.Count > 0)
            {
                cbunit.DataSource = new BindingSource(dsLoad2, null);
                cbunit.DisplayMember = "UOM";
                cbunit.ValueMember = "UOMId";
                cbunit.SelectedIndex = -1;
                cbunit.SelectedText = "select";
            }

            System.Data.DataTable dsLoad3 = DataAccessLayer.GetDataTable("subcategory_type");
            if (dsLoad3.Rows.Count > 0)
            {
                cbscategory.DataSource = new BindingSource(dsLoad3, null);
                cbscategory.DisplayMember = "CategoryName";
                cbscategory.ValueMember = "SubCategoryId";
                cbscategory.SelectedIndex = -1;
                cbscategory.SelectedText = "select";
            }
            System.Data.DataTable dsLoad4 = DataAccessLayer.GetDataTable("sp_category_type_p");
            if (dsLoad4.Rows.Count > 0)
            {
                cbsubcategoryy.DataSource = new BindingSource(dsLoad4, null);
                cbsubcategoryy.DisplayMember = "CategoryName";
                cbsubcategoryy.ValueMember = "SubsSubCategoryId";
                cbsubcategoryy.SelectedIndex = -1;
                cbsubcategoryy.SelectedText = "select";
            }

            System.Data.DataTable dsLoad5 = DataAccessLayer.GetDataTable("vendor_type_sp");
            if (dsLoad5.Rows.Count > 0)
            {
                cbvendor.DataSource = new BindingSource(dsLoad5, null);
                cbvendor.DisplayMember = "VendorName";
                cbvendor.ValueMember = "VendorId";
                cbvendor.SelectedIndex = -1;
                cbvendor.SelectedText = "select";
            }
            System.Data.DataTable dsLoad6 = DataAccessLayer.GetDataTable("brand_type_sp");
            if (dsLoad6.Rows.Count > 0)
            {
                cbbrand.DataSource = new BindingSource(dsLoad6, null);
                cbbrand.DisplayMember = "BrandName";
                cbbrand.ValueMember = "BrandId";
                cbbrand.SelectedIndex = -1;
                cbbrand.SelectedText = "select";

            }
            System.Data.DataTable dsLoad7 = DataAccessLayer.GetDataTable("uom_type_sp");
            if (dsLoad7.Rows.Count > 0)
            {
                cbvunit.DataSource = new BindingSource(dsLoad7, null);
                cbvunit.DisplayMember = "UOM";
                cbvunit.ValueMember = "UOMId";
                cbvunit.SelectedIndex = -1;
                cbvunit.SelectedText = "select";
            }
        }


        public void loadData()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RetailTestConnection"].ConnectionString);
            con.Open();
            AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
            string querry = @"select distinct [ProductName] from [Product_Mst]";
            SqlCommand cmd = new SqlCommand(querry, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows == true)
            {
                while (dr.Read())
                    namesCollection.Add(dr["ProductName"].ToString());

            }

            dr.Close();
            con.Close();

            txtproduct.AutoCompleteMode = AutoCompleteMode.Append;
            txtproduct.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtproduct.AutoCompleteCustomSource = namesCollection;
        }


        private void txtvquantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit((char)(e.KeyChar)) && e.KeyChar != ((char)(Keys.Enter)) && (e.KeyChar != (char)(Keys.Delete) || e.KeyChar == Char.Parse(".")) &&
                   e.KeyChar != (char)(Keys.Back))
                e.Handled = true;
        }

        private void txtvprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar) || char.IsPunctuation(e.KeyChar)))
                e.Handled = true;
        }

        private void txtquantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit((char)(e.KeyChar)) && e.KeyChar != ((char)(Keys.Enter)) && (e.KeyChar != (char)(Keys.Delete) || e.KeyChar == Char.Parse(".")) &&
                   e.KeyChar != (char)(Keys.Back))
                e.Handled = true;
        }

        private void txtprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar) || char.IsPunctuation(e.KeyChar)))
                e.Handled = true;
        }

        private void txtproduct_TextChanged(object sender, EventArgs e)
        {
            //TextBox t = sender as TextBox;
            //if (t != null)
            //{
            //    //say you want to do a search when user types 3 or more chars
            //    if (t.Text.Length >= 1)
            //    {
            //        //SuggestStrings will have the logic to return array of strings either from cache/db
            //        string[] arr = SuggestStrings(t.Text);

            //        AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
            //        collection.AddRange(arr);

            //        this.txtproduct.AutoCompleteCustomSource = collection;
            //    }
            //}

            loadData();
        }

        private void txtvproduct_KeyUp(object sender, KeyEventArgs e)
        {
            loadData();
        }

        private void txtproduct_KeyUp(object sender, KeyEventArgs e)
        {
            loadData();
        }

        private void txtvproduct_TextChanged(object sender, EventArgs e)
        {
            loadData();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void clear()
        {

            txtproduct.Text = String.Empty;
            txtquantity.Text = String.Empty;
            txtprice.Text = String.Empty;
            //ChkVariant.Text = String.Empty;
            cbbrand.SelectedIndex = -1;
            cbunit.SelectedIndex = -1;
            cbcategory.SelectedIndex = -1;
            cbscategory.SelectedIndex = -1;
            cbsubcategoryy.SelectedIndex = -1;

        }

        private void btngvcancel_Click(object sender, EventArgs e)
        {
            showdata();
            ChkVariant.Checked = false;
            btnadd.Enabled = true;
            clear();
        }


    }
}

