﻿namespace Retail
{
    partial class PurchaseOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.cbbrand = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbunit = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ChkVariant = new System.Windows.Forms.CheckBox();
            this.txtproduct = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbsubcategoryy = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbcategory = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbscategory = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.GvPurchaseorder = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbvendor = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbware = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ddtdate = new System.Windows.Forms.DateTimePicker();
            this.txtpurchase = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.GBproduct = new System.Windows.Forms.GroupBox();
            this.cbvunit = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtvprice = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtvproduct = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtvquantity = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btngvcancel = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnpurchase = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.Gvpurchase = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GvPurchaseorder)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.GBproduct.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gvpurchase)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnadd);
            this.groupBox1.Controls.Add(this.cbbrand);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cbunit);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtprice);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.ChkVariant);
            this.groupBox1.Controls.Add(this.txtproduct);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtquantity);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.cbsubcategoryy);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cbcategory);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cbscategory);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(40, 105);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(536, 198);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(227, 154);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(75, 23);
            this.btnadd.TabIndex = 69;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // cbbrand
            // 
            this.cbbrand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbrand.FormattingEnabled = true;
            this.cbbrand.Location = new System.Drawing.Point(351, 56);
            this.cbbrand.Name = "cbbrand";
            this.cbbrand.Size = new System.Drawing.Size(146, 21);
            this.cbbrand.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(265, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 68;
            this.label8.Text = "Brand";
            // 
            // cbunit
            // 
            this.cbunit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbunit.FormattingEnabled = true;
            this.cbunit.Location = new System.Drawing.Point(88, 116);
            this.cbunit.Name = "cbunit";
            this.cbunit.Size = new System.Drawing.Size(146, 21);
            this.cbunit.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(265, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 66;
            this.label6.Text = "Price";
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(351, 120);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(146, 20);
            this.txtprice.TabIndex = 12;
            this.txtprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprice_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 63;
            this.label1.Text = "Unit";
            // 
            // ChkVariant
            // 
            this.ChkVariant.AutoSize = true;
            this.ChkVariant.Location = new System.Drawing.Point(17, 175);
            this.ChkVariant.Name = "ChkVariant";
            this.ChkVariant.Size = new System.Drawing.Size(149, 17);
            this.ChkVariant.TabIndex = 13;
            this.ChkVariant.Text = "This Product have Variant";
            this.ChkVariant.UseVisualStyleBackColor = true;
            this.ChkVariant.Click += new System.EventHandler(this.ChkVariant_Click);
            // 
            // txtproduct
            // 
            this.txtproduct.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtproduct.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtproduct.Location = new System.Drawing.Point(88, 87);
            this.txtproduct.Name = "txtproduct";
            this.txtproduct.Size = new System.Drawing.Size(146, 20);
            this.txtproduct.TabIndex = 9;
            this.txtproduct.TextChanged += new System.EventHandler(this.txtproduct_TextChanged);
            this.txtproduct.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtproduct_KeyUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 60;
            this.label2.Text = "Product";
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(351, 87);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(146, 20);
            this.txtquantity.TabIndex = 10;
            this.txtquantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtquantity_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(263, 87);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 58;
            this.label7.Text = "Quantity";
            // 
            // cbsubcategoryy
            // 
            this.cbsubcategoryy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbsubcategoryy.FormattingEnabled = true;
            this.cbsubcategoryy.Location = new System.Drawing.Point(88, 56);
            this.cbsubcategoryy.Name = "cbsubcategoryy";
            this.cbsubcategoryy.Size = new System.Drawing.Size(146, 21);
            this.cbsubcategoryy.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 56;
            this.label5.Text = "Level2";
            // 
            // cbcategory
            // 
            this.cbcategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbcategory.FormattingEnabled = true;
            this.cbcategory.Items.AddRange(new object[] {
            "Select"});
            this.cbcategory.Location = new System.Drawing.Point(88, 24);
            this.cbcategory.Name = "cbcategory";
            this.cbcategory.Size = new System.Drawing.Size(146, 21);
            this.cbcategory.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 52;
            this.label3.Text = "Category";
            // 
            // cbscategory
            // 
            this.cbscategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbscategory.FormattingEnabled = true;
            this.cbscategory.Location = new System.Drawing.Point(351, 24);
            this.cbscategory.Name = "cbscategory";
            this.cbscategory.Size = new System.Drawing.Size(146, 21);
            this.cbscategory.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(263, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Level1";
            // 
            // GvPurchaseorder
            // 
            this.GvPurchaseorder.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.GvPurchaseorder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvPurchaseorder.Location = new System.Drawing.Point(582, 313);
            this.GvPurchaseorder.Name = "GvPurchaseorder";
            this.GvPurchaseorder.ReadOnly = true;
            this.GvPurchaseorder.Size = new System.Drawing.Size(479, 124);
            this.GvPurchaseorder.TabIndex = 19;
            this.GvPurchaseorder.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GvPurchaseorder_CellDoubleClick);
            this.GvPurchaseorder.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.GvPurchaseorder_CellMouseUp);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbvendor);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.cbware);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.ddtdate);
            this.groupBox2.Controls.Add(this.txtpurchase);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(40, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(536, 87);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // cbvendor
            // 
            this.cbvendor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbvendor.FormattingEnabled = true;
            this.cbvendor.Location = new System.Drawing.Point(351, 60);
            this.cbvendor.Name = "cbvendor";
            this.cbvendor.Size = new System.Drawing.Size(146, 21);
            this.cbvendor.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(256, 63);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 13);
            this.label12.TabIndex = 62;
            this.label12.Text = "Vendor Name";
            // 
            // cbware
            // 
            this.cbware.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbware.FormattingEnabled = true;
            this.cbware.Location = new System.Drawing.Point(99, 57);
            this.cbware.Name = "cbware";
            this.cbware.Size = new System.Drawing.Size(135, 21);
            this.cbware.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 13);
            this.label11.TabIndex = 61;
            this.label11.Text = "WareHouse";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(250, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Purchase Date";
            // 
            // ddtdate
            // 
            this.ddtdate.Enabled = false;
            this.ddtdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ddtdate.Location = new System.Drawing.Point(351, 34);
            this.ddtdate.Name = "ddtdate";
            this.ddtdate.Size = new System.Drawing.Size(146, 20);
            this.ddtdate.TabIndex = 2;
            // 
            // txtpurchase
            // 
            this.txtpurchase.Enabled = false;
            this.txtpurchase.Location = new System.Drawing.Point(99, 31);
            this.txtpurchase.Name = "txtpurchase";
            this.txtpurchase.ReadOnly = true;
            this.txtpurchase.Size = new System.Drawing.Size(135, 20);
            this.txtpurchase.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "PurchaseNo";
            // 
            // GBproduct
            // 
            this.GBproduct.Controls.Add(this.cbvunit);
            this.GBproduct.Controls.Add(this.label13);
            this.GBproduct.Controls.Add(this.txtvprice);
            this.GBproduct.Controls.Add(this.label14);
            this.GBproduct.Controls.Add(this.txtvproduct);
            this.GBproduct.Controls.Add(this.label15);
            this.GBproduct.Controls.Add(this.txtvquantity);
            this.GBproduct.Controls.Add(this.label16);
            this.GBproduct.Controls.Add(this.btngvcancel);
            this.GBproduct.Controls.Add(this.btnsave);
            this.GBproduct.Location = new System.Drawing.Point(40, 309);
            this.GBproduct.Name = "GBproduct";
            this.GBproduct.Size = new System.Drawing.Size(536, 128);
            this.GBproduct.TabIndex = 3;
            this.GBproduct.TabStop = false;
            // 
            // cbvunit
            // 
            this.cbvunit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbvunit.FormattingEnabled = true;
            this.cbvunit.Location = new System.Drawing.Point(94, 55);
            this.cbvunit.Name = "cbvunit";
            this.cbvunit.Size = new System.Drawing.Size(146, 21);
            this.cbvunit.TabIndex = 96;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(271, 59);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 13);
            this.label13.TabIndex = 101;
            this.label13.Text = "Price";
            // 
            // txtvprice
            // 
            this.txtvprice.Location = new System.Drawing.Point(357, 56);
            this.txtvprice.Name = "txtvprice";
            this.txtvprice.Size = new System.Drawing.Size(146, 20);
            this.txtvprice.TabIndex = 97;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 13);
            this.label14.TabIndex = 100;
            this.label14.Text = "Unit";
            // 
            // txtvproduct
            // 
            this.txtvproduct.Location = new System.Drawing.Point(94, 26);
            this.txtvproduct.Name = "txtvproduct";
            this.txtvproduct.Size = new System.Drawing.Size(146, 20);
            this.txtvproduct.TabIndex = 94;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 29);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 13);
            this.label15.TabIndex = 99;
            this.label15.Text = "Product";
            // 
            // txtvquantity
            // 
            this.txtvquantity.Location = new System.Drawing.Point(357, 26);
            this.txtvquantity.Name = "txtvquantity";
            this.txtvquantity.Size = new System.Drawing.Size(146, 20);
            this.txtvquantity.TabIndex = 95;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(271, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 13);
            this.label16.TabIndex = 98;
            this.label16.Text = "Quantity";
            // 
            // btngvcancel
            // 
            this.btngvcancel.Location = new System.Drawing.Point(286, 99);
            this.btngvcancel.Name = "btngvcancel";
            this.btngvcancel.Size = new System.Drawing.Size(75, 23);
            this.btngvcancel.TabIndex = 85;
            this.btngvcancel.Text = "Cancel";
            this.btngvcancel.UseVisualStyleBackColor = true;
            this.btngvcancel.Click += new System.EventHandler(this.btngvcancel_Click);
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(195, 99);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 18;
            this.btnsave.Text = "save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(131, 26);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.deleteRowToolStripMenuItem.Text = "DeleteRow";
            this.deleteRowToolStripMenuItem.Click += new System.EventHandler(this.deleteRowToolStripMenuItem_Click);
            // 
            // btnpurchase
            // 
            this.btnpurchase.Location = new System.Drawing.Point(501, 467);
            this.btnpurchase.Name = "btnpurchase";
            this.btnpurchase.Size = new System.Drawing.Size(75, 23);
            this.btnpurchase.TabIndex = 20;
            this.btnpurchase.Text = "Purchase";
            this.btnpurchase.UseVisualStyleBackColor = true;
            this.btnpurchase.Click += new System.EventHandler(this.btnpurchase_Click);
            // 
            // btncancel
            // 
            this.btncancel.Location = new System.Drawing.Point(601, 467);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 21;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // Gvpurchase
            // 
            this.Gvpurchase.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.Gvpurchase.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gvpurchase.Location = new System.Drawing.Point(582, 21);
            this.Gvpurchase.Name = "Gvpurchase";
            this.Gvpurchase.Size = new System.Drawing.Size(479, 282);
            this.Gvpurchase.TabIndex = 22;
            // 
            // PurchaseOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1284, 669);
            this.Controls.Add(this.Gvpurchase);
            this.Controls.Add(this.GBproduct);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnpurchase);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.GvPurchaseorder);
            this.Controls.Add(this.groupBox1);
            this.Name = "PurchaseOrder";
            this.Text = "PurchaseOrder";
            this.Load += new System.EventHandler(this.PurchaseOrder_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GvPurchaseorder)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.GBproduct.ResumeLayout(false);
            this.GBproduct.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Gvpurchase)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView GvPurchaseorder;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker ddtdate;
        private System.Windows.Forms.TextBox txtpurchase;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbscategory;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbsubcategoryy;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbcategory;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbvendor;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbware;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox ChkVariant;
        private System.Windows.Forms.TextBox txtproduct;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbbrand;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbunit;
        private System.Windows.Forms.GroupBox GBproduct;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
        private System.Windows.Forms.Button btnpurchase;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.DataGridView Gvpurchase;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.ComboBox cbvunit;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtvprice;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtvproduct;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtvquantity;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btngvcancel;
    }
}