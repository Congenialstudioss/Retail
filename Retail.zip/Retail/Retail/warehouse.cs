﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;
using System.Resources;
using System.Reflection;

namespace Retail
{
    public partial class warehouse : Form
    {
        int indexRow;
        public warehouse()
        {
            InitializeComponent();
            Loadwarehouse();
            txtwcontact.MaxLength = 10;
            txtwcontactno.MaxLength = 10;

        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = Gvwarehouse.Rows[indexRow];
                    hstbl.Add("@status", "Delete");
                    hstbl.Add("updatedby", Global.UserID);
                    hstbl.Add("@WarehouseId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_warehouse_master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" warehouse Details Deleted Successfully.", "warehouse Alert");
                        txtwareno.Text = String.Empty;
                        txtwname.Text = String.Empty;
                        txtwcontact.Text = String.Empty;
                        txtwcontactno.Text = String.Empty;
                        txtwarehouse.Text = String.Empty;
                        Loadwarehouse();
                    }
                }
            }

            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }

        private void Gvwarehouse_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.Gvwarehouse.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.Gvwarehouse.CurrentCell = this.Gvwarehouse.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.Gvwarehouse, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void Gvwarehouse_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = Gvwarehouse.Rows[indexRow];
            txtwareno.Text = row.Cells[2].Value.ToString();
            txtwname.Text = row.Cells[3].Value.ToString();
            txtwarehouse.Text = row.Cells[4].Value.ToString();
            txtwcontact.Text = row.Cells[5].Value.ToString();
            txtwcontactno.Text = row.Cells[6].Value.ToString();
            btnwsave.Text = "Update";
        }

        private void btnwsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtwareno.Text != String.Empty && txtwname.Text != String.Empty && txtwarehouse.Text != String.Empty && txtwcontact.Text != String.Empty && txtwcontactno.Text != String.Empty)
                {
                    if (btnwsave.Text == "Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");
                        hstbl.Add("@WarehouseNo", txtwareno.Text.Trim());
                        hstbl.Add("@WarehouseName", txtwname.Text.Trim());
                        hstbl.Add("@Address", txtwarehouse.Text.Trim());
                        hstbl.Add("@ContactNo1", txtwcontact.Text.Trim());
                        hstbl.Add("@ContactNo2", txtwcontactno.Text.Trim());
                        hstbl.Add("@createdby", Global.UserID);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_warehouse_master", hstbl);
                        if (intidentity != null && intidentity > 0)
                        {
                            MessageBox.Show("Warehouse Details Saved Sucessfully", "Warehouse Alert");
                            //txtwareno.Text = String.Empty;
                            txtwname.Text = String.Empty;
                            txtwcontact.Text = String.Empty;
                            txtwcontactno.Text = String.Empty;
                            txtwarehouse.Text = String.Empty;
                            Loadwarehouse();
                            bind();
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Warehouse");

                        }
                    }

                    else if (btnwsave.Text == "Update")
                    {
                        Hashtable hstbl = new Hashtable();
                        DataGridViewRow row = Gvwarehouse.Rows[indexRow];
                        hstbl.Add("@status", "Update");
                        hstbl.Add("@WarehouseName", txtwname.Text.Trim());
                        hstbl.Add("@Address", txtwarehouse.Text.Trim());
                        hstbl.Add("@ContactNo1", txtwcontact.Text.Trim());
                        hstbl.Add("@ContactNo2", txtwcontactno.Text.Trim());
                        hstbl.Add("updatedby", Global.UserID);
                        hstbl.Add("@WarehouseId", row.Cells[1].Value);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_warehouse_master", hstbl);
                        if (intidentity != null && intidentity > 0)
                        {
                            MessageBox.Show("Warehouse Details Updated Sucessfully", "Warehouse Alert");
                            //txtwareno.Text = String.Empty;
                            txtwname.Text = String.Empty;
                            txtwcontact.Text = String.Empty;
                            txtwcontactno.Text = String.Empty;
                            txtwarehouse.Text = String.Empty;
                            Loadwarehouse();
                            bind();
                            btnwsave.Text = "Save";
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Warehouse");

                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter the Warehouse");

                }

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }

        protected void Loadwarehouse()
        {

            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@status", "Get");
                DataSet ds = DataAccessLayer.GetDataset("sp_warehouse_master", hstbl);
                Gvwarehouse.DataSource = ds.Tables[0];
                Gvwarehouse.Columns[1].Visible = false;
                Gvwarehouse.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                DataGridViewCellStyle style = Gvwarehouse.ColumnHeadersDefaultCellStyle;
                style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                style.Font = new Font(Gvwarehouse.Font, FontStyle.Bold);
                Gvwarehouse.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkBlue;
                Gvwarehouse.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                Gvwarehouse.EnableHeadersVisualStyles = false;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }

        private void warehouse_Load(object sender, EventArgs e)
        {

            // txtwareno.Attribute.Add("readonly", "readonly");


            //DataSet getquote = DataAccessLayer.GetDataSet("sp_retailcode_fetch");
            //if (getquote.Tables[0].Rows.Count > 0)
            //{
            //    txtwareno.Text = getquote.Tables[0].Rows[0]["WarehouseNo"].ToString();
            //}
            //Loadwarehouse();

            bind();
        }

        public  void bind()
                    {   DataSet getquote = DataAccessLayer.GetDataSet("sp_retailcode_fetch");
            if (getquote.Tables[0].Rows.Count > 0)
            {
                txtwareno.Text = getquote.Tables[0].Rows[0]["WarehouseNo"].ToString();
            }
            Loadwarehouse();
        }
            
        private void txtcontact_keypress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtcontctno_keypress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtcontct_validating(object sender, CancelEventArgs e)
        {
            if (txtwcontact.Text != txtwcontactno.Text)
            {

            }
            else
            {
                MessageBox.Show("Already entered the number");
            }
        }

        private void txtphone_validating(object sender, CancelEventArgs e)
        {
            if (txtwcontactno.Text != txtwcontact.Text)
            {

            }
            else
            {
                MessageBox.Show("Already entered the number");
            }
        }


    }
}