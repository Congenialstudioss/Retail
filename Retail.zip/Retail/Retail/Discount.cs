﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;


namespace Retail 
{
    public partial class Discount : Form
    {
        int indexRow;
        public Discount()
        {
            InitializeComponent();
            LoadDiscount();
           
        }

        private void GvDiscount_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = GvDiscount.Rows[indexRow];
            txtdiscount.Text = row.Cells[2].Value.ToString();
            btndiscount.Text = "Update";
        }

        private void GvDiscount_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.GvDiscount.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.GvDiscount.CurrentCell = this.GvDiscount.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.GvDiscount, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = GvDiscount.Rows[indexRow];
                    hstbl.Add("@status", "Delete");
                    hstbl.Add("updatedby", Global.UserID);
                    hstbl.Add("@DiscountId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_discount_master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" Discount Details Deleted Successfully.", "Discount Alert");
                        txtdiscount.Text = String.Empty;
                        LoadDiscount();
                    }
                }
            }

            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btndiscount_Click(object sender, EventArgs e)
        {

            try
            {
                if (txtdiscount.Text != String.Empty)
                {
                    if (btndiscount.Text == "Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");
                        hstbl.Add("@DiscountType", txtdiscount.Text);
                        hstbl.Add("@createdby", Global.UserID);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_discount_master", hstbl);
                        if (intidentity != null && intidentity > 0)
                        {
                            MessageBox.Show("Discount Details Saved Sucessfully", "Discount Alert");
                            txtdiscount.Text = string.Empty;
                            LoadDiscount();
                        }

                        else
                        {
                            MessageBox.Show("Already Entered the Discount");

                        }
                    }
                    else if (btndiscount.Text == "Update")
                    {
                        Hashtable hstbl = new Hashtable();
                        DataGridViewRow row = GvDiscount.Rows[indexRow];
                        hstbl.Add("@status", "Update");
                        hstbl.Add("@DiscountType", txtdiscount.Text.Trim());
                        hstbl.Add("updatedby", Global.UserID);
                        hstbl.Add("@DiscountId  ", row.Cells[1].Value);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_discount_master", hstbl);
                        if ( intidentity != null && intidentity > 0)
                        {
                            MessageBox.Show("Discount Details Updated Sucessfully", "Discount Alert");
                            txtdiscount.Text = string.Empty;
                            LoadDiscount();
                            btndiscount.Text = "Save";
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Discount");

                        }

                    }
                }
                else
                {
                    MessageBox.Show("Please Enter the Discount");

                }

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
    
        }

        protected void LoadDiscount()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@status", "Get");
                DataSet ds = DataAccessLayer.GetDataset("sp_discount_master", hstbl);
                GvDiscount.DataSource = ds.Tables[0];
                GvDiscount.Columns[1].Visible = false;
                GvDiscount.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                DataGridViewCellStyle style = GvDiscount.ColumnHeadersDefaultCellStyle;
                style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                style.Font = new Font(GvDiscount.Font, FontStyle.Bold);
                GvDiscount.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkBlue;
                GvDiscount.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                GvDiscount.EnableHeadersVisualStyles = false;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        } 
    
    }
    }
