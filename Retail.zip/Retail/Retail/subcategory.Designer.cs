﻿namespace Retail
{
    partial class subcategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblCategoryId = new System.Windows.Forms.Label();
            this.txtscname = new System.Windows.Forms.TextBox();
            this.btnscsave = new System.Windows.Forms.Button();
            this.lblscname = new System.Windows.Forms.Label();
            this.cbcategory = new System.Windows.Forms.ComboBox();
            this.GvSubcategory = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.GvSubcategory)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCategoryId
            // 
            this.lblCategoryId.AutoSize = true;
            this.lblCategoryId.Location = new System.Drawing.Point(51, 43);
            this.lblCategoryId.Name = "lblCategoryId";
            this.lblCategoryId.Size = new System.Drawing.Size(49, 13);
            this.lblCategoryId.TabIndex = 0;
            this.lblCategoryId.Text = "Category";
            // 
            // txtscname
            // 
            this.txtscname.Location = new System.Drawing.Point(191, 77);
            this.txtscname.Name = "txtscname";
            this.txtscname.Size = new System.Drawing.Size(156, 20);
            this.txtscname.TabIndex = 2;
            // 
            // btnscsave
            // 
            this.btnscsave.Location = new System.Drawing.Point(158, 117);
            this.btnscsave.Name = "btnscsave";
            this.btnscsave.Size = new System.Drawing.Size(75, 23);
            this.btnscsave.TabIndex = 3;
            this.btnscsave.Text = "Save";
            this.btnscsave.UseVisualStyleBackColor = true;
            this.btnscsave.Click += new System.EventHandler(this.btnscsave_Click);
            // 
            // lblscname
            // 
            this.lblscname.AutoSize = true;
            this.lblscname.Location = new System.Drawing.Point(51, 77);
            this.lblscname.Name = "lblscname";
            this.lblscname.Size = new System.Drawing.Size(102, 13);
            this.lblscname.TabIndex = 4;
            this.lblscname.Text = "Sub Category Name";
            // 
            // cbcategory
            // 
            this.cbcategory.FormattingEnabled = true;
            this.cbcategory.Items.AddRange(new object[] {
            "--Select--"});
            this.cbcategory.Location = new System.Drawing.Point(191, 43);
            this.cbcategory.Name = "cbcategory";
            this.cbcategory.Size = new System.Drawing.Size(156, 21);
            this.cbcategory.TabIndex = 5;
            // 
            // GvSubcategory
            // 
            this.GvSubcategory.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.GvSubcategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvSubcategory.Location = new System.Drawing.Point(54, 146);
            this.GvSubcategory.Name = "GvSubcategory";
            this.GvSubcategory.ReadOnly = true;
            this.GvSubcategory.Size = new System.Drawing.Size(293, 150);
            this.GvSubcategory.TabIndex = 6;
            this.GvSubcategory.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GvSubcatergory_Dobleclick);
            this.GvSubcategory.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Gv_Mouseup);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(131, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextmenustrip);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.deleteRowToolStripMenuItem.Text = "DeleteRow";
            // 
            // subcategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 319);
            this.Controls.Add(this.GvSubcategory);
            this.Controls.Add(this.cbcategory);
            this.Controls.Add(this.lblscname);
            this.Controls.Add(this.btnscsave);
            this.Controls.Add(this.txtscname);
            this.Controls.Add(this.lblCategoryId);
            this.Name = "subcategory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "subcategory";
            this.Load += new System.EventHandler(this.subcategory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GvSubcategory)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCategoryId;
        private System.Windows.Forms.TextBox txtscname;
        private System.Windows.Forms.Button btnscsave;
        private System.Windows.Forms.Label lblscname;
        private System.Windows.Forms.ComboBox cbcategory;
        private System.Windows.Forms.DataGridView GvSubcategory;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
    }
}