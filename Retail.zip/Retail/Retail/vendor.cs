﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;
namespace Retail
{
    public partial class vendor : Form
    {
       int indexRow;
        public vendor()
        {
            InitializeComponent();
            Loadvendor();
            txtvconatctno1.MaxLength = 10;
            txtvcontactno2.MaxLength = 10;
        }

        private void vendor_Load(object sender, EventArgs e)
        {
            bind();
        }

       
        private void GvVendor_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = GvVendor.Rows[indexRow];
          txtvendorno.Text = row.Cells[2].Value.ToString();
            txtvendorname.Text = row.Cells[3].Value.ToString();
           txtaddress.Text = row.Cells[4].Value.ToString();
            txtvconatctno1.Text = row.Cells[5].Value.ToString();
            txtvcontactno2.Text = row.Cells[6].Value.ToString();
            btnsave.Text = "Update";
        }

        private void GvVendor_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.GvVendor.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.GvVendor.CurrentCell = this.GvVendor.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.GvVendor, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
             try
            {
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = GvVendor.Rows[indexRow];
                    hstbl.Add("@status", "Delete");
                    hstbl.Add("updatedby", Global.UserID);
                    hstbl.Add("@VendorId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_vendor_master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" Vendor Details Deleted Successfully.", "Vendor Alert");
                        txtvendorno.Text = String.Empty;
                        txtvendorname.Text = String.Empty;
                        txtaddress.Text = String.Empty;
                        txtvcontactno2.Text = String.Empty;
                        txtvconatctno1.Text = String.Empty;
                          Loadvendor();
                          bind();
                    }
                }
            }

            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void Loadvendor()
       {
           try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@status", "Get");
                DataSet ds = DataAccessLayer.GetDataset("sp_vendor_master", hstbl);
                GvVendor.DataSource = ds.Tables[0];
                GvVendor.Columns[1].Visible = false;
               GvVendor.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
               DataGridViewCellStyle style = GvVendor.ColumnHeadersDefaultCellStyle;
               style.Alignment = DataGridViewContentAlignment.MiddleCenter;
               style.Font = new Font(GvVendor.Font, FontStyle.Bold);
               GvVendor.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkBlue;
               GvVendor.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
               GvVendor.EnableHeadersVisualStyles = false;
               GvVendor.Columns[3].HeaderText = "Vendor Name";
              
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

       }

        private void btnsave_Click(object sender, EventArgs e)
        {
          try
            {
                if (txtvendorno.Text != String.Empty && txtvendorname.Text != String.Empty && txtaddress.Text != String.Empty && txtvconatctno1.Text != String.Empty &&  txtvcontactno2.Text != String.Empty)
                {
                    if ( btnsave.Text == "Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");
                        hstbl.Add("@VendorNo", txtvendorno.Text.Trim());
                        hstbl.Add("@VendorName", txtvendorname.Text.Trim());
                        hstbl.Add("@Address", txtaddress.Text.Trim());
                        hstbl.Add("@ContactNo1", txtvconatctno1.Text.Trim());
                        hstbl.Add("@ContactNo2", txtvcontactno2.Text.Trim());
                        hstbl.Add("@createdby", Global.UserID);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_vendor_master", hstbl);
                        if (intidentity != null && intidentity > 0)
                        {
                            MessageBox.Show("Vendor Details Saved Sucessfully", "Vendor Alert");
                            //txtvendorno.Text = String.Empty;
                            txtvendorname.Text = String.Empty;
                            txtvconatctno1.Text = String.Empty;
                            txtvcontactno2.Text = String.Empty;
                            txtaddress.Text = String.Empty;
                            Loadvendor();
                            bind();
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Vendor");

                        }
                    }
                    else if ( btnsave.Text == "Update")
                    {
                        Hashtable hstbl = new Hashtable();
                        DataGridViewRow row = GvVendor.Rows[indexRow];
                        hstbl.Add("@status", "Update");
                        hstbl.Add("@VendorName", txtvendorname.Text.Trim());
                        hstbl.Add("@Address", txtaddress.Text.Trim());
                        hstbl.Add("@ContactNo1", txtvconatctno1.Text.Trim());
                        hstbl.Add("@ContactNo2",  txtvcontactno2.Text.Trim());
                        hstbl.Add("updatedby", Global.UserID);
                        hstbl.Add("@VendorId", row.Cells[1].Value);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_vendor_master", hstbl);
                        if (intidentity != null && intidentity > 0)
                        {
                            MessageBox.Show("Vendor Details Updated Sucessfully", "Vendor Alert");
                            //txtvendorno.Text = String.Empty;
                            txtvendorname.Text = String.Empty;
                            txtaddress.Text = String.Empty;
                            txtvconatctno1.Text = String.Empty;
                             txtvcontactno2.Text = String.Empty;
                           
                            Loadvendor();
                            bind();
                             btnsave.Text = "Save";
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Vendor");

                        }


                    }
                }
                else
                {
                    MessageBox.Show("Please Enter the Vendor");

                }

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
             public  void bind()
                    { 
                 DataSet getquote = DataAccessLayer.GetDataSet("sp_vendor_fetch");
            if (getquote.Tables[0].Rows.Count > 0)
            {
                txtvendorno.Text = getquote.Tables[0].Rows[0]["VendorNo"].ToString();
            }
            Loadvendor();
        }

             private void contact_validating(object sender, CancelEventArgs e)
             {
                 if(txtvconatctno1.Text!=txtvcontactno2.Text)
                 {
                     
                 }
                 else
                 {
                     MessageBox.Show("Already entered the number");
                 }
             }

           

          

             private void txtphone_keypress(object sender, KeyPressEventArgs e)
             {

                 if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                     e.Handled = true;
             }

             private void txtcontact_keypress(object sender, KeyPressEventArgs e)
             {
                 if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                     e.Handled = true;
             }

             private void phone_validating(object sender, CancelEventArgs e)
             {
                 if (txtvcontactno2.Text != txtvconatctno1.Text)
                 {

                 }
                 else
                 {
                     MessageBox.Show("Already entered the number");
                 }
             }

    }
}
