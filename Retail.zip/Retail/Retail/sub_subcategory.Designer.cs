﻿namespace Retail
{
    partial class sub_subcategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblSubCategoryname = new System.Windows.Forms.Label();
            this.btnsssave = new System.Windows.Forms.Button();
            this.txtsubname = new System.Windows.Forms.TextBox();
            this.lblSubCategoryId = new System.Windows.Forms.Label();
            this.cbsubcategory = new System.Windows.Forms.ComboBox();
            this.GvSub_Category = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.GvSub_Category)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSubCategoryname
            // 
            this.lblSubCategoryname.AutoSize = true;
            this.lblSubCategoryname.Location = new System.Drawing.Point(77, 79);
            this.lblSubCategoryname.Name = "lblSubCategoryname";
            this.lblSubCategoryname.Size = new System.Drawing.Size(99, 13);
            this.lblSubCategoryname.TabIndex = 9;
            this.lblSubCategoryname.Text = "SubCategory Name";
            // 
            // btnsssave
            // 
            this.btnsssave.Location = new System.Drawing.Point(162, 123);
            this.btnsssave.Name = "btnsssave";
            this.btnsssave.Size = new System.Drawing.Size(75, 23);
            this.btnsssave.TabIndex = 8;
            this.btnsssave.Text = "Save";
            this.btnsssave.UseVisualStyleBackColor = true;
            this.btnsssave.Click += new System.EventHandler(this.btnsssave_Click);
            // 
            // txtsubname
            // 
            this.txtsubname.Location = new System.Drawing.Point(207, 79);
            this.txtsubname.Name = "txtsubname";
            this.txtsubname.Size = new System.Drawing.Size(156, 20);
            this.txtsubname.TabIndex = 7;
            // 
            // lblSubCategoryId
            // 
            this.lblSubCategoryId.AutoSize = true;
            this.lblSubCategoryId.Location = new System.Drawing.Point(77, 43);
            this.lblSubCategoryId.Name = "lblSubCategoryId";
            this.lblSubCategoryId.Size = new System.Drawing.Size(68, 13);
            this.lblSubCategoryId.TabIndex = 5;
            this.lblSubCategoryId.Text = "SubCategory";
            // 
            // cbsubcategory
            // 
            this.cbsubcategory.FormattingEnabled = true;
            this.cbsubcategory.Location = new System.Drawing.Point(207, 43);
            this.cbsubcategory.Name = "cbsubcategory";
            this.cbsubcategory.Size = new System.Drawing.Size(156, 21);
            this.cbsubcategory.TabIndex = 10;
            // 
            // GvSub_Category
            // 
            this.GvSub_Category.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.GvSub_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvSub_Category.Location = new System.Drawing.Point(80, 162);
            this.GvSub_Category.Name = "GvSub_Category";
            this.GvSub_Category.ReadOnly = true;
            this.GvSub_Category.Size = new System.Drawing.Size(283, 150);
            this.GvSub_Category.TabIndex = 11;
            this.GvSub_Category.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GvSubCategory_DoubleClick);
            this.GvSub_Category.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.GvSSubcategory_mouseup);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(131, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextmenustripclick);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.deleteRowToolStripMenuItem.Text = "DeleteRow";
            // 
            // sub_subcategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 324);
            this.Controls.Add(this.GvSub_Category);
            this.Controls.Add(this.cbsubcategory);
            this.Controls.Add(this.lblSubCategoryname);
            this.Controls.Add(this.btnsssave);
            this.Controls.Add(this.txtsubname);
            this.Controls.Add(this.lblSubCategoryId);
            this.Name = "sub_subcategory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "sub_subcategory";
            this.Load += new System.EventHandler(this.sub_subcategory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GvSub_Category)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSubCategoryname;
        private System.Windows.Forms.Button btnsssave;
        private System.Windows.Forms.TextBox txtsubname;
        private System.Windows.Forms.Label lblSubCategoryId;
        private System.Windows.Forms.ComboBox cbsubcategory;
        private System.Windows.Forms.DataGridView GvSub_Category;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
    }
}