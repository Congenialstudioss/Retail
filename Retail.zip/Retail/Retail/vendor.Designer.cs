﻿namespace Retail
{
    partial class vendor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gboxvendor = new System.Windows.Forms.GroupBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnvsave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblcontact = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.txtvcontactno2 = new System.Windows.Forms.TextBox();
            this.txtvconatctno1 = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblvname = new System.Windows.Forms.Label();
            this.txtvendorname = new System.Windows.Forms.TextBox();
            this.txtvendorno = new System.Windows.Forms.TextBox();
            this.lblvendorno = new System.Windows.Forms.Label();
            this.GvVendor = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gboxvendor.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GvVendor)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gboxvendor
            // 
            this.gboxvendor.Controls.Add(this.btnsave);
            this.gboxvendor.Controls.Add(this.button4);
            this.gboxvendor.Controls.Add(this.label4);
            this.gboxvendor.Controls.Add(this.groupBox1);
            this.gboxvendor.Controls.Add(this.lblcontact);
            this.gboxvendor.Controls.Add(this.button3);
            this.gboxvendor.Controls.Add(this.txtvcontactno2);
            this.gboxvendor.Controls.Add(this.txtvconatctno1);
            this.gboxvendor.Controls.Add(this.txtaddress);
            this.gboxvendor.Controls.Add(this.lbladdress);
            this.gboxvendor.Controls.Add(this.lblvname);
            this.gboxvendor.Controls.Add(this.txtvendorname);
            this.gboxvendor.Controls.Add(this.txtvendorno);
            this.gboxvendor.Controls.Add(this.lblvendorno);
            this.gboxvendor.Location = new System.Drawing.Point(48, 12);
            this.gboxvendor.Name = "gboxvendor";
            this.gboxvendor.Size = new System.Drawing.Size(688, 194);
            this.gboxvendor.TabIndex = 0;
            this.gboxvendor.TabStop = false;
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(287, 165);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 10;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(380, 275);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 2;
            this.button4.Text = "Cancel";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(377, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Alternative No";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnvsave);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(0, 223);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(725, 195);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btnvsave
            // 
            this.btnvsave.Location = new System.Drawing.Point(287, 159);
            this.btnvsave.Name = "btnvsave";
            this.btnvsave.Size = new System.Drawing.Size(75, 23);
            this.btnvsave.TabIndex = 1;
            this.btnvsave.Text = "Save";
            this.btnvsave.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(366, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Contact No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(366, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Contact No";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(481, 109);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(160, 20);
            this.textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(481, 73);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(160, 20);
            this.textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(131, 80);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(189, 52);
            this.textBox3.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(47, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(366, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Vendor Name";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(481, 42);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(160, 20);
            this.textBox4.TabIndex = 2;
            // 
            // textBox5
            // 
            this.textBox5.Enabled = false;
            this.textBox5.Location = new System.Drawing.Point(131, 42);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(189, 20);
            this.textBox5.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(47, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Vendor No";
            // 
            // lblcontact
            // 
            this.lblcontact.AutoSize = true;
            this.lblcontact.Location = new System.Drawing.Point(377, 79);
            this.lblcontact.Name = "lblcontact";
            this.lblcontact.Size = new System.Drawing.Size(61, 13);
            this.lblcontact.TabIndex = 8;
            this.lblcontact.Text = "Contact No";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(261, 275);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 1;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // txtvcontactno2
            // 
            this.txtvcontactno2.Location = new System.Drawing.Point(481, 112);
            this.txtvcontactno2.Name = "txtvcontactno2";
            this.txtvcontactno2.Size = new System.Drawing.Size(160, 20);
            this.txtvcontactno2.TabIndex = 7;
            this.txtvcontactno2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtphone_keypress);
            this.txtvcontactno2.Validating += new System.ComponentModel.CancelEventHandler(this.phone_validating);
            // 
            // txtvconatctno1
            // 
            this.txtvconatctno1.Location = new System.Drawing.Point(481, 76);
            this.txtvconatctno1.Name = "txtvconatctno1";
            this.txtvconatctno1.Size = new System.Drawing.Size(160, 20);
            this.txtvconatctno1.TabIndex = 6;
            this.txtvconatctno1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontact_keypress);
            this.txtvconatctno1.Validating += new System.ComponentModel.CancelEventHandler(this.contact_validating);
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(131, 73);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(189, 50);
            this.txtaddress.TabIndex = 5;
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(47, 79);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(45, 13);
            this.lbladdress.TabIndex = 4;
            this.lbladdress.Text = "Address";
            // 
            // lblvname
            // 
            this.lblvname.AutoSize = true;
            this.lblvname.Location = new System.Drawing.Point(377, 45);
            this.lblvname.Name = "lblvname";
            this.lblvname.Size = new System.Drawing.Size(72, 13);
            this.lblvname.TabIndex = 3;
            this.lblvname.Text = "Vendor Name";
            // 
            // txtvendorname
            // 
            this.txtvendorname.Location = new System.Drawing.Point(481, 42);
            this.txtvendorname.Name = "txtvendorname";
            this.txtvendorname.Size = new System.Drawing.Size(160, 20);
            this.txtvendorname.TabIndex = 2;
            // 
            // txtvendorno
            // 
            this.txtvendorno.Enabled = false;
            this.txtvendorno.Location = new System.Drawing.Point(131, 38);
            this.txtvendorno.Name = "txtvendorno";
            this.txtvendorno.ReadOnly = true;
            this.txtvendorno.Size = new System.Drawing.Size(189, 20);
            this.txtvendorno.TabIndex = 1;
            // 
            // lblvendorno
            // 
            this.lblvendorno.AutoSize = true;
            this.lblvendorno.Location = new System.Drawing.Point(47, 45);
            this.lblvendorno.Name = "lblvendorno";
            this.lblvendorno.Size = new System.Drawing.Size(58, 13);
            this.lblvendorno.TabIndex = 0;
            this.lblvendorno.Text = "Vendor No";
            // 
            // GvVendor
            // 
            this.GvVendor.AllowUserToOrderColumns = true;
            this.GvVendor.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.GvVendor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvVendor.Location = new System.Drawing.Point(48, 212);
            this.GvVendor.Name = "GvVendor";
            this.GvVendor.ReadOnly = true;
            this.GvVendor.Size = new System.Drawing.Size(688, 194);
            this.GvVendor.TabIndex = 1;
            this.GvVendor.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GvVendor_CellDoubleClick);
            this.GvVendor.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.GvVendor_CellMouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(134, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.deleteRowToolStripMenuItem.Text = "Delete Row";
            // 
            // vendor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(781, 429);
            this.Controls.Add(this.GvVendor);
            this.Controls.Add(this.gboxvendor);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "vendor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "vendor";
            this.Load += new System.EventHandler(this.vendor_Load);
            this.gboxvendor.ResumeLayout(false);
            this.gboxvendor.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GvVendor)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gboxvendor;
        private System.Windows.Forms.Label lblvname;
        private System.Windows.Forms.TextBox txtvendorname;
        private System.Windows.Forms.TextBox txtvendorno;
        private System.Windows.Forms.Label lblvendorno;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblcontact;
        private System.Windows.Forms.TextBox txtvcontactno2;
        private System.Windows.Forms.TextBox txtvconatctno1;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Button btnvsave;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView GvVendor;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
        private System.Windows.Forms.Button btnsave;
    }
}