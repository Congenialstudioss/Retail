﻿namespace Retail
{
    partial class ProductHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.product = new System.Windows.Forms.GroupBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.cbsubcategory = new System.Windows.Forms.ComboBox();
            this.cbsscategory = new System.Windows.Forms.ComboBox();
            this.cbcategory = new System.Windows.Forms.ComboBox();
            this.cbunit = new System.Windows.Forms.ComboBox();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.txtproduct = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtpurchase = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.GvPHistory = new System.Windows.Forms.DataGridView();
            this.product.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GvPHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // product
            // 
            this.product.Controls.Add(this.btnsave);
            this.product.Controls.Add(this.cbsubcategory);
            this.product.Controls.Add(this.cbsscategory);
            this.product.Controls.Add(this.cbcategory);
            this.product.Controls.Add(this.cbunit);
            this.product.Controls.Add(this.txtprice);
            this.product.Controls.Add(this.txtquantity);
            this.product.Controls.Add(this.txtproduct);
            this.product.Controls.Add(this.label8);
            this.product.Controls.Add(this.label6);
            this.product.Controls.Add(this.label4);
            this.product.Controls.Add(this.label2);
            this.product.Controls.Add(this.label7);
            this.product.Controls.Add(this.label5);
            this.product.Controls.Add(this.label3);
            this.product.Controls.Add(this.txtpurchase);
            this.product.Controls.Add(this.label1);
            this.product.Location = new System.Drawing.Point(51, 27);
            this.product.Name = "product";
            this.product.Size = new System.Drawing.Size(587, 207);
            this.product.TabIndex = 1;
            this.product.TabStop = false;
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(255, 167);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 24;
            this.btnsave.Text = "save";
            this.btnsave.UseVisualStyleBackColor = true;
            // 
            // cbsubcategory
            // 
            this.cbsubcategory.FormattingEnabled = true;
            this.cbsubcategory.Location = new System.Drawing.Point(391, 52);
            this.cbsubcategory.Name = "cbsubcategory";
            this.cbsubcategory.Size = new System.Drawing.Size(146, 21);
            this.cbsubcategory.TabIndex = 23;
            // 
            // cbsscategory
            // 
            this.cbsscategory.FormattingEnabled = true;
            this.cbsscategory.Location = new System.Drawing.Point(110, 85);
            this.cbsscategory.Name = "cbsscategory";
            this.cbsscategory.Size = new System.Drawing.Size(157, 21);
            this.cbsscategory.TabIndex = 22;
            // 
            // cbcategory
            // 
            this.cbcategory.FormattingEnabled = true;
            this.cbcategory.Location = new System.Drawing.Point(110, 52);
            this.cbcategory.Name = "cbcategory";
            this.cbcategory.Size = new System.Drawing.Size(157, 21);
            this.cbcategory.TabIndex = 21;
            // 
            // cbunit
            // 
            this.cbunit.FormattingEnabled = true;
            this.cbunit.Location = new System.Drawing.Point(391, 83);
            this.cbunit.Name = "cbunit";
            this.cbunit.Size = new System.Drawing.Size(146, 21);
            this.cbunit.TabIndex = 20;
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(391, 119);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(146, 20);
            this.txtprice.TabIndex = 15;
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(110, 122);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(157, 20);
            this.txtquantity.TabIndex = 14;
            // 
            // txtproduct
            // 
            this.txtproduct.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtproduct.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtproduct.Location = new System.Drawing.Point(391, 20);
            this.txtproduct.Name = "txtproduct";
            this.txtproduct.Size = new System.Drawing.Size(146, 20);
            this.txtproduct.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(306, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(306, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "UOM";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(306, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "SubCategory";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(306, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Product";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 122);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Quantity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "SubSubCategory";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Category";
            // 
            // txtpurchase
            // 
            this.txtpurchase.Location = new System.Drawing.Point(110, 20);
            this.txtpurchase.Name = "txtpurchase";
            this.txtpurchase.Size = new System.Drawing.Size(157, 20);
            this.txtpurchase.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Purchaseorder";
            // 
            // GvPHistory
            // 
            this.GvPHistory.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.GvPHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvPHistory.Location = new System.Drawing.Point(51, 240);
            this.GvPHistory.Name = "GvPHistory";
            this.GvPHistory.Size = new System.Drawing.Size(587, 215);
            this.GvPHistory.TabIndex = 2;
            // 
            // ProductHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 483);
            this.Controls.Add(this.GvPHistory);
            this.Controls.Add(this.product);
            this.Name = "ProductHistory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProductHistory";
            this.product.ResumeLayout(false);
            this.product.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GvPHistory)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox product;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.ComboBox cbsubcategory;
        private System.Windows.Forms.ComboBox cbsscategory;
        private System.Windows.Forms.ComboBox cbcategory;
        private System.Windows.Forms.ComboBox cbunit;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.TextBox txtproduct;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtpurchase;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView GvPHistory;
    }
}