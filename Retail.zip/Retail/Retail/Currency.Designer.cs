﻿namespace Retail
{
    partial class Currency
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtcurrency = new System.Windows.Forms.TextBox();
            this.lblcurrency = new System.Windows.Forms.Label();
            this.btncurrency = new System.Windows.Forms.Button();
            this.GvCurrency = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.GvCurrency)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtcurrency
            // 
            this.txtcurrency.Location = new System.Drawing.Point(135, 59);
            this.txtcurrency.Name = "txtcurrency";
            this.txtcurrency.Size = new System.Drawing.Size(115, 20);
            this.txtcurrency.TabIndex = 0;
            // 
            // lblcurrency
            // 
            this.lblcurrency.AutoSize = true;
            this.lblcurrency.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcurrency.Location = new System.Drawing.Point(62, 62);
            this.lblcurrency.Name = "lblcurrency";
            this.lblcurrency.Size = new System.Drawing.Size(57, 13);
            this.lblcurrency.TabIndex = 1;
            this.lblcurrency.Text = "Currency";
            // 
            // btncurrency
            // 
            this.btncurrency.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncurrency.Location = new System.Drawing.Point(125, 101);
            this.btncurrency.Name = "btncurrency";
            this.btncurrency.Size = new System.Drawing.Size(75, 23);
            this.btncurrency.TabIndex = 2;
            this.btncurrency.Text = "Save";
            this.btncurrency.UseVisualStyleBackColor = true;
            this.btncurrency.Click += new System.EventHandler(this.btncurrency_Click);
            // 
            // GvCurrency
            // 
            this.GvCurrency.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.GvCurrency.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvCurrency.Location = new System.Drawing.Point(65, 130);
            this.GvCurrency.Name = "GvCurrency";
            this.GvCurrency.ReadOnly = true;
            this.GvCurrency.Size = new System.Drawing.Size(217, 150);
            this.GvCurrency.TabIndex = 3;
            this.GvCurrency.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gvcurrency_CellDoubleClick);
            this.GvCurrency.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Gvcurrency_CellMouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(131, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.deleteRowToolStripMenuItem.Text = "DeleteRow";
            // 
            // Currency
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(310, 313);
            this.Controls.Add(this.GvCurrency);
            this.Controls.Add(this.btncurrency);
            this.Controls.Add(this.lblcurrency);
            this.Controls.Add(this.txtcurrency);
            this.Name = "Currency";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Currency";
            ((System.ComponentModel.ISupportInitialize)(this.GvCurrency)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtcurrency;
        private System.Windows.Forms.Label lblcurrency;
        private System.Windows.Forms.Button btncurrency;
        private System.Windows.Forms.DataGridView GvCurrency;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
    }
}