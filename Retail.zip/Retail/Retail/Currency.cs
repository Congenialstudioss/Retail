﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;

namespace Retail
{
    public partial class Currency : Form
    {
        int indexRow;
        public Currency()
        {
            InitializeComponent();
               Loadcurrency();
        }

        private void Gvcurrency_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = GvCurrency.Rows[indexRow];
            txtcurrency.Text = row.Cells[2].Value.ToString();
            btncurrency.Text = "Update";
        }

        private void Gvcurrency_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.GvCurrency.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.GvCurrency.CurrentCell = this.GvCurrency.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.GvCurrency, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }

        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {

            try
            {
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = GvCurrency.Rows[indexRow];
                    hstbl.Add("@status", "Delete");
                    hstbl.Add("updatedby", Global.UserID);
                    hstbl.Add("@CurrencyId ", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_currency_master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" Currency Details Deleted Successfully.", "Currency Alert");
                        txtcurrency.Text = String.Empty;
                        Loadcurrency();
                    }
                }
            }

            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }

        private void btncurrency_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtcurrency.Text != String.Empty)
                {
                    if(btncurrency.Text=="Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");
                        hstbl.Add("@Currency", txtcurrency.Text);
                        hstbl.Add("@createdby", Global.UserID);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_currency_master", hstbl);
                        if (intidentity != null && intidentity > 0)
                        {
                            MessageBox.Show("Currency Details Saved Sucessfully", "Currency Alert");
                           txtcurrency.Text = string.Empty;
                            Loadcurrency();
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Currency");

                        }
                     }
                     else if(btncurrency.Text=="Update")
                    {
                        Hashtable hstbl=new Hashtable();
                          DataGridViewRow row = GvCurrency.Rows[indexRow];
                        hstbl.Add("@status","Update");
                        hstbl.Add("@Currency", txtcurrency.Text.Trim());
                        hstbl.Add("updatedby",Global.UserID);
                         hstbl.Add("@CurrencyId ", row.Cells[1].Value);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_currency_master", hstbl);
                        if (intidentity != null && intidentity > 0)
                        {
                            MessageBox.Show("Currency Details Updated Sucessfully", "Currency Alert");
                            txtcurrency.Text = string.Empty;
                            Loadcurrency();
                           btncurrency.Text="Save";
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Currency");

                        }


                    }
                }
                else{
                    MessageBox.Show("Please Enter the Currency");

                }

            }
        catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void    Loadcurrency()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@status", "Get");
                DataSet ds = DataAccessLayer.GetDataset("sp_currency_master", hstbl);
                GvCurrency.DataSource = ds.Tables[0];
                GvCurrency.Columns[1].Visible = false;
                GvCurrency.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                DataGridViewCellStyle style = GvCurrency.ColumnHeadersDefaultCellStyle;
                style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                style.Font = new Font(GvCurrency.Font, FontStyle.Bold);
                GvCurrency.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkBlue;
                GvCurrency.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                GvCurrency.EnableHeadersVisualStyles = false;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

                    }
                }
            