﻿namespace Retail
{
    partial class warehouse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnwsave = new System.Windows.Forms.Button();
            this.gboxwarehouse = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtwcontactno = new System.Windows.Forms.TextBox();
            this.txtwcontact = new System.Windows.Forms.TextBox();
            this.txtwarehouse = new System.Windows.Forms.TextBox();
            this.lblwaddress = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtwname = new System.Windows.Forms.TextBox();
            this.txtwareno = new System.Windows.Forms.TextBox();
            this.lblwhno = new System.Windows.Forms.Label();
            this.Gvwarehouse = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gboxwarehouse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gvwarehouse)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnwsave
            // 
            this.btnwsave.Location = new System.Drawing.Point(284, 137);
            this.btnwsave.Name = "btnwsave";
            this.btnwsave.Size = new System.Drawing.Size(75, 23);
            this.btnwsave.TabIndex = 4;
            this.btnwsave.Text = "Save";
            this.btnwsave.UseVisualStyleBackColor = true;
            this.btnwsave.Click += new System.EventHandler(this.btnwsave_Click);
            // 
            // gboxwarehouse
            // 
            this.gboxwarehouse.Controls.Add(this.label8);
            this.gboxwarehouse.Controls.Add(this.btnwsave);
            this.gboxwarehouse.Controls.Add(this.label9);
            this.gboxwarehouse.Controls.Add(this.txtwcontactno);
            this.gboxwarehouse.Controls.Add(this.txtwcontact);
            this.gboxwarehouse.Controls.Add(this.txtwarehouse);
            this.gboxwarehouse.Controls.Add(this.lblwaddress);
            this.gboxwarehouse.Controls.Add(this.label11);
            this.gboxwarehouse.Controls.Add(this.txtwname);
            this.gboxwarehouse.Controls.Add(this.txtwareno);
            this.gboxwarehouse.Controls.Add(this.lblwhno);
            this.gboxwarehouse.Location = new System.Drawing.Point(80, 40);
            this.gboxwarehouse.Name = "gboxwarehouse";
            this.gboxwarehouse.Size = new System.Drawing.Size(685, 175);
            this.gboxwarehouse.TabIndex = 3;
            this.gboxwarehouse.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(369, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Alternative No";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(369, 71);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Contact No";
            // 
            // txtwcontactno
            // 
            this.txtwcontactno.Location = new System.Drawing.Point(497, 97);
            this.txtwcontactno.Name = "txtwcontactno";
            this.txtwcontactno.Size = new System.Drawing.Size(160, 20);
            this.txtwcontactno.TabIndex = 7;
            this.txtwcontactno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontctno_keypress);
            this.txtwcontactno.Validating += new System.ComponentModel.CancelEventHandler(this.txtphone_validating);
            // 
            // txtwcontact
            // 
            this.txtwcontact.Location = new System.Drawing.Point(497, 71);
            this.txtwcontact.Name = "txtwcontact";
            this.txtwcontact.Size = new System.Drawing.Size(160, 20);
            this.txtwcontact.TabIndex = 6;
            this.txtwcontact.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontact_keypress);
            this.txtwcontact.Validating += new System.ComponentModel.CancelEventHandler(this.txtcontct_validating);
            // 
            // txtwarehouse
            // 
            this.txtwarehouse.Location = new System.Drawing.Point(131, 68);
            this.txtwarehouse.Multiline = true;
            this.txtwarehouse.Name = "txtwarehouse";
            this.txtwarehouse.Size = new System.Drawing.Size(189, 51);
            this.txtwarehouse.TabIndex = 5;
            // 
            // lblwaddress
            // 
            this.lblwaddress.AutoSize = true;
            this.lblwaddress.Location = new System.Drawing.Point(47, 71);
            this.lblwaddress.Name = "lblwaddress";
            this.lblwaddress.Size = new System.Drawing.Size(45, 13);
            this.lblwaddress.TabIndex = 4;
            this.lblwaddress.Text = "Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(369, 45);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Warehouse Name";
            // 
            // txtwname
            // 
            this.txtwname.Location = new System.Drawing.Point(497, 45);
            this.txtwname.Name = "txtwname";
            this.txtwname.Size = new System.Drawing.Size(160, 20);
            this.txtwname.TabIndex = 2;
            // 
            // txtwareno
            // 
            this.txtwareno.Enabled = false;
            this.txtwareno.Location = new System.Drawing.Point(131, 42);
            this.txtwareno.Name = "txtwareno";
            this.txtwareno.ReadOnly = true;
            this.txtwareno.Size = new System.Drawing.Size(189, 20);
            this.txtwareno.TabIndex = 1;
            // 
            // lblwhno
            // 
            this.lblwhno.AutoSize = true;
            this.lblwhno.Location = new System.Drawing.Point(47, 45);
            this.lblwhno.Name = "lblwhno";
            this.lblwhno.Size = new System.Drawing.Size(79, 13);
            this.lblwhno.TabIndex = 0;
            this.lblwhno.Text = "Warehouse No";
            // 
            // Gvwarehouse
            // 
            this.Gvwarehouse.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.Gvwarehouse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gvwarehouse.Location = new System.Drawing.Point(80, 236);
            this.Gvwarehouse.Name = "Gvwarehouse";
            this.Gvwarehouse.ReadOnly = true;
            this.Gvwarehouse.Size = new System.Drawing.Size(685, 150);
            this.Gvwarehouse.TabIndex = 6;
            this.Gvwarehouse.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gvwarehouse_CellDoubleClick);
            this.Gvwarehouse.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Gvwarehouse_CellMouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(131, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.deleteRowToolStripMenuItem.Text = "DeleteRow";
            // 
            // warehouse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 426);
            this.Controls.Add(this.Gvwarehouse);
            this.Controls.Add(this.gboxwarehouse);
            this.Name = "warehouse";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "warehouse";
            this.Load += new System.EventHandler(this.warehouse_Load);
            this.gboxwarehouse.ResumeLayout(false);
            this.gboxwarehouse.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gvwarehouse)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnwsave;
        private System.Windows.Forms.GroupBox gboxwarehouse;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtwcontactno;
        private System.Windows.Forms.TextBox txtwcontact;
        private System.Windows.Forms.TextBox txtwarehouse;
        private System.Windows.Forms.Label lblwaddress;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtwname;
        private System.Windows.Forms.TextBox txtwareno;
        private System.Windows.Forms.Label lblwhno;
        private System.Windows.Forms.DataGridView Gvwarehouse;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
    }
}