﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;

namespace Retail
{
    public partial class UOM : Form
    {  
        int indexRow;
        public UOM()
        {
            InitializeComponent();
            Loaduom();
        }
   
        private void btnuomsave_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtuom.Text !=String.Empty)
                {
                    if(btnuomsave.Text=="Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");
                        hstbl.Add("uom", txtuom.Text.Trim());
                        hstbl.Add("@createdby", Global.UserID);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_uom_master", hstbl);
                        if (intidentity!= null && intidentity > 0)
                        {
                            MessageBox.Show("UOM Details Saved Sucessfully", "Uom Alert");
                            txtuom.Text = string.Empty;
                            Loaduom();
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the uom");

                        }
                     }
                        

                    else if(btnuomsave.Text=="Update")
                    {
                        Hashtable hstbl=new Hashtable();
                          DataGridViewRow row = GvUom.Rows[indexRow];
                        hstbl.Add("@status","Update");
                        hstbl.Add("@uom",txtuom.Text.Trim());
                        hstbl.Add("@updatedby",Global.UserID);
                         hstbl.Add("@uom_id", row.Cells[1].Value);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_uom_master", hstbl);
                        if (intidentity!=null && intidentity > 0)
                        {
                                MessageBox.Show("UOM Details Updated Sucessfully", "Uom Alert");
                            txtuom.Text = string.Empty;
                            Loaduom();
                            btnuomsave.Text="Save";
                        }
                        else 
                        {
                            MessageBox.Show("Already Entered the UOM");
                       
                        }

                    }
                }
                else{
                    MessageBox.Show("Please Enter The UOM");

                }

            }
        catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void Loaduom()
        {
            try
            {
                Hashtable hstbl=new Hashtable();
                hstbl.Add("@status","Get");
                DataSet ds=DataAccessLayer.GetDataset("sp_uom_master",hstbl);
                GvUom.DataSource = ds.Tables[0];
                GvUom.Columns[1].Visible = false;
                GvUom.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                DataGridViewCellStyle style = GvUom.ColumnHeadersDefaultCellStyle;
                style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                style.Font = new Font(GvUom.Font, FontStyle.Bold);
                GvUom.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkBlue;
                GvUom.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                GvUom.EnableHeadersVisualStyles = false;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Gvuom_cellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = GvUom.Rows[indexRow];
            txtuom.Text = row.Cells[2].Value.ToString();
            btnuomsave.Text="Update";
                 
        }

     
        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
                try
                {
                    if(MessageBox.Show("Do want to Delete ?", "Warning",MessageBoxButtons.YesNo)==System.Windows.Forms.DialogResult.Yes)
                    {
                        Hashtable hstbl=new Hashtable();
                        DataGridViewRow row= GvUom.Rows[indexRow];
                         hstbl.Add("@status", "Delete");
                         hstbl.Add("updatedby", Global.UserID);
                        hstbl.Add("@uom_id", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_uom_master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" UOM Details Deleted Successfully.", "UOM Alert");
                        txtuom.Text = String.Empty;
                        Loaduom();
                    }
                   }
                }

                 catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        
        }

     
             private void GvUOM_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.GvUom.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.GvUom.CurrentCell = this.GvUom.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.GvUom, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }


       
     

    }
}
