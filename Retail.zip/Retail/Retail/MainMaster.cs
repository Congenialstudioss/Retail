﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;

namespace Retail
{
    public partial class MainMaster : Form
    {
        public MainMaster()
        {
            InitializeComponent();
        }

        private void uOMToolStripMenuItem_Click(object sender, EventArgs e)
        {

            UOM um = new UOM();
            um.ShowDialog();
           
        }

        private void brandToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Brand br = new Brand();
            br.ShowDialog();
        }

        private void currencyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Currency cr = new Currency();
            cr.ShowDialog();
        }

        private void catergoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Category ct = new Category();
            ct.ShowDialog();
        }

        private void discountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Discount dt = new Discount();
            dt.ShowDialog();
        }

        private void warehouseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            warehouse wh = new warehouse();
            wh.ShowDialog();
        }

        private void vendorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            vendor vr = new vendor();
            vr.ShowDialog();

        }

        private void subCategoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            subcategory sc = new subcategory();
            sc.ShowDialog();
        }

        private void itemSubCategoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sub_subcategory ssc = new sub_subcategory();
            ssc.ShowDialog();
        }

        private void productToolStripMenuItem_Click(object sender, EventArgs e)
        {
            product pd = new product();
            pd.ShowDialog();
        }

        private void MainMaster_Load(object sender, EventArgs e)
        {
            Timer tmr = new Timer();
            tmr.Interval = 1000;
            tmr.Tick += new EventHandler(tmr_Tick);
            tmr.Start();
            lbluser.Text = Global.UserName;
        }

        private void tmr_Tick(object sender, EventArgs e)
        
        {
         lbldate.Text = DateTime.Now.ToString("MMM/dd/yyyy HH:mm:ss");
            //LblUTCTime.Text   = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss");          
        }

        private void masterToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void purchaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PurchaseOrder po = new PurchaseOrder();
            po.ShowDialog();      
        }

        private void stockInToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stockin si = new Stockin();
            si.ShowDialog();
        }

    }
}
