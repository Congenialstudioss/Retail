﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;

namespace Retail
{
    public partial class Stockin : Form
    {
        int indexRow;
        public Stockin()
        {
            InitializeComponent();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            DisplayRecord();
         
        }

        protected void DisplayRecord()
        {
            try
            {
                if (txtpurchase.Text != String.Empty || txtwarehouse.Text != String.Empty)
                {
                    Hashtable hst = new Hashtable();
                    hst.Add("@RegNo", txtpurchase.Text != string.Empty ? txtpurchase.Text : (object)DBNull.Value);
                    hst.Add("@Warehouse", txtwarehouse.Text != string.Empty ? txtwarehouse.Text : (object)DBNull.Value);

                    DataSet ds = DataAccessLayer.GetDataset("puchase_data_sp", hst);
                    GvStockin.DataSource = ds.Tables[0];
                    GvStockin.Columns[2].Visible = false;
                    GvStockin.Columns[3].Visible = false;
                    GvStockin.Columns[4].Visible = false;
                    GvStockin.Columns[6].Visible = false;
                    //GvStockin.Columns[8].Visible = false;
                    GvStockin.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Stockin_Load(object sender, EventArgs e)
        {

        }

        private void GvStockin_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
            Global.New = "Edit";
            saleupdate su = new saleupdate();
            su.ShowDialog();
        }

        private void GvStockin_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
 
