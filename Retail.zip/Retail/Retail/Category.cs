﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;

namespace Retail
{    
    
    public partial class Category : Form
    {
        int indexRow;
        public Category()
        {
            InitializeComponent();
            LoadCategory();
        }

        private void GvCategory_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = GvCategory.Rows[indexRow];
            txtcategory.Text = row.Cells[2].Value.ToString();
            btncategory.Text = "Update";
        }

        private void GvCategory_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
             if (e.Button == MouseButtons.Right)
            {
                this.GvCategory.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.GvCategory.CurrentCell = this.GvCategory.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.GvCategory, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }

        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = GvCategory.Rows[indexRow];
                    hstbl.Add("@status", "Delete");
                    hstbl.Add("updatedby", Global.UserID);
                    hstbl.Add("@CategoryId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_category_master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" Category Details Deleted Successfully.", "Category Alert");
                        txtcategory.Text =String.Empty;
                        LoadCategory();
                    }
                }
            }

            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btncategory_Click(object sender, EventArgs e)
        {
             try
            {
                if(txtcategory.Text != String.Empty)
                {
                    if(btncategory.Text=="Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");
                        hstbl.Add("@CategoryName", txtcategory.Text);
                        hstbl.Add("@createdby", Global.UserID);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_category_master", hstbl);
                        if (intidentity!= null && intidentity > 0)
                        {
                            MessageBox.Show("Category Details Saved Sucessfully", "Category Alert");
                           txtcategory.Text = string.Empty;
                            LoadCategory();
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Category");
         
                        }
                     }
                     else if(btncategory.Text=="Update")
                    {
                        Hashtable hstbl=new Hashtable();
                          DataGridViewRow row = GvCategory.Rows[indexRow];
                        hstbl.Add("@status","Update");
                        hstbl.Add("@CategoryName", txtcategory.Text.Trim());
                        hstbl.Add("updatedby",Global.UserID);
                         hstbl.Add("@CategoryId  ", row.Cells[1].Value);
                        Int64 dt= DataAccessLayer.ExecuteCommand_RowsAffected("sp_category_master", hstbl);
                        if (dt!=null && dt > 0)
                        {
                            MessageBox.Show("Category Details Updated Sucessfully", "Category Alert");
                            txtcategory.Text = string.Empty;
                            LoadCategory();
                           btncategory.Text="Save";
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Category");
                           
                        }
                    }
                }
                else{
                    MessageBox.Show("Please Enter the Category");

                }

            }
        catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void    LoadCategory()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@status", "Get");
                DataSet ds = DataAccessLayer.GetDataset("sp_category_master", hstbl);
                GvCategory.DataSource = ds.Tables[0];
                GvCategory.Columns[1].Visible = false;
                GvCategory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                DataGridViewCellStyle style = GvCategory.ColumnHeadersDefaultCellStyle;
                style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                style.Font = new Font(GvCategory.Font, FontStyle.Bold);
                GvCategory.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkBlue;
                GvCategory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                GvCategory.EnableHeadersVisualStyles = false;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
    


    }
}
