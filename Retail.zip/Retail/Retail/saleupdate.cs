﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Sample;
using System.Collections;

namespace Retail
{
    public partial class saleupdate : Form
    {
        public saleupdate()
        {
            InitializeComponent();
        }

        private void saleupdate_Load(object sender, EventArgs e)
        {
            var newform = Global.New;

            if(newform=="Edit")
            {
                DisplayRecord();
            }
          
        }
        protected void DisplayRecord()
        {
            try
            {
               
                    Hashtable hstbl = new Hashtable();
                    hstbl.Add("@StatementType", "Update");
                    hstbl.Add("@Purchaseno", txtpurchase.Text);
                    hstbl.Add("@warehouseId", txtswarehouse.Text);
                    hstbl.Add("@Product", txtproduct.Text);
                    hstbl.Add("@UomId", cbunit.SelectedValue);
                    hstbl.Add("@Quantity", txtquantity.Text);
                    hstbl.Add("@ReceivedQuantity", txtrquantity.Text);
                    hstbl.Add("@BrandId",txtbrand.Text);
                    hstbl.Add("@Price", txtprice.Text);
                    hstbl.Add("@UpdatedBy", Global.UserID);
                    //hstbl.Add("@Purchaseno", row.Cells[1].Value);


                     Int64 intidentity   = DataAccessLayer.ExecuteCommand_RowsAffected("Purchase_tbl_sp", hstbl);

                     if (intidentity > 0)
                     {
                         MessageBox.Show("Stock Update Suceessfully", "stock Error");
                     }

                
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        public void bind()
        {

            System.Data.DataTable dsLoad2 = DataAccessLayer.GetDataTable("uom_type_sp");
            if (dsLoad2.Rows.Count > 0)
            {
                cbunit.DataSource = new BindingSource(dsLoad2, null);
                cbunit.DisplayMember = "UOM";
                cbunit.ValueMember = "UOMId";
                cbunit.SelectedIndex = -1;
                cbunit.SelectedText = "select";
            }
        }
       
    }
}
