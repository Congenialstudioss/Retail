﻿namespace Retail
{
    partial class product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Gvproduct = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnsave = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbarcode = new System.Windows.Forms.TextBox();
            this.txtproduct = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtpname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbbrand = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbunit = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtinternal = new System.Windows.Forms.TextBox();
            this.cbssubcategory = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbcategory = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbsubcategory = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Gvproduct)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Gvproduct
            // 
            this.Gvproduct.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.Gvproduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gvproduct.Location = new System.Drawing.Point(54, 239);
            this.Gvproduct.Name = "Gvproduct";
            this.Gvproduct.ReadOnly = true;
            this.Gvproduct.Size = new System.Drawing.Size(843, 166);
            this.Gvproduct.TabIndex = 11;
            this.Gvproduct.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gvproduct_doubleclick);
            this.Gvproduct.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.GvProduct_MouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem,
            this.editRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(131, 48);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenustripclick);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.deleteRowToolStripMenuItem.Text = "DeleteRow";
            this.deleteRowToolStripMenuItem.Click += new System.EventHandler(this.deleteRowToolStripMenuItem_Click);
            // 
            // editRowToolStripMenuItem
            // 
            this.editRowToolStripMenuItem.Name = "editRowToolStripMenuItem";
            this.editRowToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.editRowToolStripMenuItem.Text = "EditRow";
            this.editRowToolStripMenuItem.Click += new System.EventHandler(this.editRowToolStripMenuItem_Click);
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(370, 172);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 10;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtbarcode);
            this.groupBox1.Controls.Add(this.txtproduct);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtpname);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cbbrand);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.cbunit);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtinternal);
            this.groupBox1.Controls.Add(this.cbssubcategory);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.cbcategory);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.cbsubcategory);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.btnsave);
            this.groupBox1.Location = new System.Drawing.Point(54, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(843, 212);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(525, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 91;
            this.label3.Text = "BarcodeNo";
            // 
            // txtbarcode
            // 
            this.txtbarcode.Location = new System.Drawing.Point(644, 32);
            this.txtbarcode.Name = "txtbarcode";
            this.txtbarcode.Size = new System.Drawing.Size(131, 20);
            this.txtbarcode.TabIndex = 3;
            // 
            // txtproduct
            // 
            this.txtproduct.Location = new System.Drawing.Point(111, 29);
            this.txtproduct.Name = "txtproduct";
            this.txtproduct.ReadOnly = true;
            this.txtproduct.Size = new System.Drawing.Size(131, 20);
            this.txtproduct.TabIndex = 1;
            this.txtproduct.TextChanged += new System.EventHandler(this.txtproduct_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 89;
            this.label1.Text = "ProductNo";
            // 
            // txtpname
            // 
            this.txtpname.Location = new System.Drawing.Point(370, 32);
            this.txtpname.Name = "txtpname";
            this.txtpname.Size = new System.Drawing.Size(131, 20);
            this.txtpname.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(270, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 87;
            this.label2.Text = "ProductName";
            // 
            // cbbrand
            // 
            this.cbbrand.FormattingEnabled = true;
            this.cbbrand.Location = new System.Drawing.Point(370, 70);
            this.cbbrand.Name = "cbbrand";
            this.cbbrand.Size = new System.Drawing.Size(131, 21);
            this.cbbrand.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(270, 76);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 85;
            this.label10.Text = "Brand";
            // 
            // cbunit
            // 
            this.cbunit.FormattingEnabled = true;
            this.cbunit.Location = new System.Drawing.Point(644, 70);
            this.cbunit.Name = "cbunit";
            this.cbunit.Size = new System.Drawing.Size(131, 21);
            this.cbunit.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(525, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 13);
            this.label5.TabIndex = 83;
            this.label5.Text = "Unit";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 81;
            this.label4.Text = "InternalNo";
            // 
            // txtinternal
            // 
            this.txtinternal.Location = new System.Drawing.Point(111, 70);
            this.txtinternal.Name = "txtinternal";
            this.txtinternal.Size = new System.Drawing.Size(131, 20);
            this.txtinternal.TabIndex = 4;
            // 
            // cbssubcategory
            // 
            this.cbssubcategory.FormattingEnabled = true;
            this.cbssubcategory.Location = new System.Drawing.Point(644, 111);
            this.cbssubcategory.Name = "cbssubcategory";
            this.cbssubcategory.Size = new System.Drawing.Size(131, 21);
            this.cbssubcategory.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(525, 118);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 13);
            this.label9.TabIndex = 79;
            this.label9.Text = "SubSub Category";
            // 
            // cbcategory
            // 
            this.cbcategory.FormattingEnabled = true;
            this.cbcategory.Location = new System.Drawing.Point(111, 110);
            this.cbcategory.Name = "cbcategory";
            this.cbcategory.Size = new System.Drawing.Size(131, 21);
            this.cbcategory.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 77;
            this.label6.Text = "Category";
            // 
            // cbsubcategory
            // 
            this.cbsubcategory.FormattingEnabled = true;
            this.cbsubcategory.Location = new System.Drawing.Point(370, 110);
            this.cbsubcategory.Name = "cbsubcategory";
            this.cbsubcategory.Size = new System.Drawing.Size(131, 21);
            this.cbsubcategory.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(261, 118);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 75;
            this.label7.Text = "subcategory";
            // 
            // product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 436);
            this.Controls.Add(this.Gvproduct);
            this.Controls.Add(this.groupBox1);
            this.Name = "product";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product                                                                          " +
    "                                                     ";
            this.Load += new System.EventHandler(this.product_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Gvproduct)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Gvproduct;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbarcode;
        private System.Windows.Forms.TextBox txtproduct;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbbrand;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbunit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtinternal;
        private System.Windows.Forms.ComboBox cbssubcategory;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbcategory;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbsubcategory;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ToolStripMenuItem editRowToolStripMenuItem;
    }
}