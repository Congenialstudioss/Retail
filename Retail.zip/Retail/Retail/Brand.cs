﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;


namespace Retail
{
    public partial class Brand : Form
    {
        int indexRow;
        public Brand()
        {
            InitializeComponent();
            Loadbrand();

        }

        private void btnbrand_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtbrand.Text !=String.Empty)
                {
                     if(btnbrand.Text=="Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");
                        hstbl.Add("@brandname", txtbrand.Text.Trim());
                        hstbl.Add("@createdby", Global.UserID);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_brand_master", hstbl);
                       if(intidentity!=null && intidentity>0)
                        {
                            MessageBox.Show("Brand Details Saved Sucessfully", "Brand Alert");
                            txtbrand.Text = string.Empty;
                            Loadbrand();
                        }
                       else
                       {
                           MessageBox.Show("Already Entered the Brand");
                        
                       }
                     }
                     else if(btnbrand.Text=="Update")
                    {
                        Hashtable hstbl=new Hashtable();
                          DataGridViewRow row = GvBrand.Rows[indexRow];
                        hstbl.Add("@status","Update");
                        hstbl.Add("@brandname",txtbrand.Text.Trim());
                        hstbl.Add("@updatedby",Global.UserID);
                         hstbl.Add("@brand_id", row.Cells[1].Value);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_brand_master", hstbl);
                        if (intidentity!= null && intidentity > 0)
                        {
                            MessageBox.Show("Brand Details Updated Sucessfully", "Brand Alert");
                            txtbrand.Text = string.Empty;
                            Loadbrand();
                            btnbrand.Text="save";
                        }
                        else
                        {
                            MessageBox.Show("Already Entered the Brand");
                           
                        }

                    }
                }
                else{
                    MessageBox.Show("Please Enter the brand");

                }

            }
        catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void Loadbrand()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@status", "Get");
                DataSet ds = DataAccessLayer.GetDataset("sp_brand_master", hstbl);
                GvBrand.DataSource = ds.Tables[0];
                GvBrand.Columns[1].Visible = false;
                GvBrand.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Gvbrand_cellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = GvBrand.Rows[indexRow];
            txtbrand.Text = row.Cells[2].Value.ToString();
            btnbrand.Text = "Update";

        }


        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = GvBrand.Rows[indexRow];
                    hstbl.Add("@status", "Delete");
                    hstbl.Add("updatedby", Global.UserID);
                    hstbl.Add("@brand_id",row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_brand_master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" Brand Details Deleted Successfully.", "Brand Alert");
                        txtbrand.Text = String.Empty;
                        Loadbrand();
                    }
                }
            }

            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }


        private void Gvbrand_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.GvBrand.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.GvBrand.CurrentCell = this.GvBrand.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.GvBrand, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }



     
      
    }
}
