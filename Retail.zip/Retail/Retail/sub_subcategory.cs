﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Sample;

namespace Retail
{
    public partial class sub_subcategory : Form
    {
        int indexRow;
        public sub_subcategory()
        {
            InitializeComponent();
        }

        private void sub_subcategory_Load(object sender, EventArgs e)
        {
            bind();
            loadssubcategory();
        }

        private void GvSubCategory_DoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = GvSub_Category.Rows[indexRow];
            cbsubcategory.Text = row.Cells[2].Value.ToString();
            txtsubname.Text = row.Cells[3].Value.ToString();
            btnsssave.Text = "Update";
        }

        private void contextmenustripclick(object sender, EventArgs e)
        {

            try
            {
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = GvSub_Category.Rows[indexRow];
                    hstbl.Add("@status", "Delete");
                    hstbl.Add("updatedby", Global.UserID);
                    hstbl.Add("@SubsSubCategoryId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_ssubcategory_master", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show(" Subcategory Details Deleted Successfully.", "Subcategory Alert");
                        cbsubcategory.Text = String.Empty;
                        txtsubname.Text = String.Empty;
                        loadssubcategory();
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void GvSSubcategory_mouseup(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.GvSub_Category.Rows[e.RowIndex].Selected = true;
                indexRow = e.RowIndex;
                this.GvSub_Category.CurrentCell = this.GvSub_Category.Rows[e.RowIndex].Cells[2];
                this.contextMenuStrip1.Show(this.GvSub_Category, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void btnsssave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtsubname.Text != String.Empty)
                {
                    if (btnsssave.Text == "Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@status", "insert");

                        hstbl.Add("@SubCategoryId", cbsubcategory.SelectedValue);
                        hstbl.Add("@CategoryName", txtsubname.Text.Trim());
                        hstbl.Add("@createdby", 1);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_ssubcategory_master", hstbl);
                        if (intidentity > 0)
                        {
                            MessageBox.Show("Subcategory Details Saved Sucessfully", "Subcategory Alert");
                            txtsubname.Text = String.Empty;
                            loadssubcategory();
                            bind();
                        }

                    }

                    else if (btnsssave.Text == "Update")
                    {
                        Hashtable hstbl = new Hashtable();
                        DataGridViewRow row = GvSub_Category.Rows[indexRow];
                        hstbl.Add("@status", "update");
                        hstbl.Add("@SubCategoryId", cbsubcategory.SelectedValue);
                        hstbl.Add("@CategoryName", txtsubname.Text.Trim());
                        hstbl.Add("updatedby", Global.UserID);
                        hstbl.Add("@SubsSubCategoryId", row.Cells[1].Value);
                        Int64 intidentity = DataAccessLayer.ExecuteCommand_RowsAffected("sp_ssubcategory_master", hstbl);
                        if (intidentity > 0)
                        {
                            MessageBox.Show("Subcategory  Details Updated Sucessfully", "Subcategory  Alert");
                            loadssubcategory();
                            bind();
                            btnsssave.Text = "Save";
                        }

                    }
                }
                else
                {
                    MessageBox.Show("Please Enter the Subcategory");

                }

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void loadssubcategory()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@status", "Get");
                DataSet ds = DataAccessLayer.GetDataset("sp_ssubcategory_master", hstbl);
                GvSub_Category.DataSource = ds.Tables[0];
                GvSub_Category.Columns[1].Visible = false;
                GvSub_Category.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                DataGridViewCellStyle style = GvSub_Category.ColumnHeadersDefaultCellStyle;
                style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                style.Font = new Font(GvSub_Category.Font, FontStyle.Bold);
                GvSub_Category.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkBlue;
                GvSub_Category.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                GvSub_Category.EnableHeadersVisualStyles = false;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }

        public void bind()
        {
            System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("subcategory_type");

            if (dsLoad != null)
            {
                if (dsLoad.Rows.Count > 0)
                {
                    cbsubcategory.DataSource = new BindingSource(dsLoad, null);
                    cbsubcategory.DisplayMember = "CategoryName";
                    cbsubcategory.ValueMember = "SubCategoryId";
                    cbsubcategory.SelectedIndex = 0;
                }
            }
        }
    



    }
}
